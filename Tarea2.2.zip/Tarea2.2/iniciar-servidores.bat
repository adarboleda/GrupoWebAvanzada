@echo off
REM Script para iniciar/reiniciar servidores frontend y backend
REM Si están corriendo, los reinicia. Si están apagados, los inicia.

setlocal enabledelayedexpansion

echo.
echo ========================================
echo    GESTOR DE SERVIDORES
echo ========================================
echo.

REM Detener procesos Node existentes
echo [*] Deteniendo procesos Node existentes...
taskkill /F /IM node.exe 2>nul
if !ERRORLEVEL! EQU 0 (
    echo [✓] Procesos Node detenidos
) else (
    echo [i] No hay procesos Node activos
)
timeout /t 2 /nobreak

REM Cambiar a directorio del backend
cd /d "c:\ESPE\WebAvanzada\Unidad 2\Tarea2.2\backend-gestion-notas"

REM Verificar que exista package.json
if not exist package.json (
    echo [✗] Error: No se encontró package.json en backend
    pause
    exit /b 1
)

REM Iniciar backend en una ventana separada
echo.
echo [*] Iniciando Backend en http://localhost:3001...
start cmd /k "title Backend Gestion Notas && npm start"

timeout /t 3 /nobreak

REM Cambiar a directorio del frontend
cd /d "c:\ESPE\WebAvanzada\Unidad 2\Tarea2.2\frontend-gestion-notas"

REM Verificar que exista package.json
if not exist package.json (
    echo [✗] Error: No se encontró package.json en frontend
    pause
    exit /b 1
)

REM Iniciar frontend en una ventana separada
echo.
echo [*] Iniciando Frontend en http://localhost:3000...
start cmd /k "title Frontend Gestion Notas && npm start"

timeout /t 2 /nobreak

echo.
echo ========================================
echo [✓] Servidores iniciados:
echo    - Backend:  http://localhost:3001
echo    - Frontend: http://localhost:3000
echo ========================================
echo.
echo Nota: Se han abierto dos ventanas nuevas.
echo Presiona Ctrl+C en cada ventana para detener los servidores.
echo.

pause
