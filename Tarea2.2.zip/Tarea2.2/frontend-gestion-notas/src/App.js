import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Layout } from './components/Layout/Layout';
import PrivateRoute from './components/PrivateRoute';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import EstudiantesPage from './components/Estudiantes/EstudiantesPage';
import DocentesPage from './components/Docentes/DocentesPage';
import NotasPage from './components/Notas/NotasPage';
import AyudaPage from './pages/AyudaPage';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function AppContent() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Cargando...</span>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Rutas públicas */}
      <Route path="/login" element={<LoginPage />} />

      {/* Rutas protegidas */}
      <Route
        path="/dashboard"
        element={
          <PrivateRoute>
            <Layout>
              <DashboardPage />
            </Layout>
          </PrivateRoute>
        }
      />

      <Route
        path="/estudiantes"
        element={
          <PrivateRoute>
            <Layout>
              <EstudiantesPage />
            </Layout>
          </PrivateRoute>
        }
      />

      <Route
        path="/docentes"
        element={
          <PrivateRoute>
            <Layout>
              <DocentesPage />
            </Layout>
          </PrivateRoute>
        }
      />

      <Route
        path="/notas"
        element={
          <PrivateRoute>
            <Layout>
              <NotasPage />
            </Layout>
          </PrivateRoute>
        }
      />

      <Route
        path="/ayuda"
        element={
          <PrivateRoute>
            <Layout>
              <AyudaPage />
            </Layout>
          </PrivateRoute>
        }
      />

      {/* Redireccionar raíz */}
      <Route path="/" element={<Navigate to={isAuthenticated ? '/dashboard' : '/login'} replace />} />

      {/* 404 */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;