import React from 'react';
import { Row, Col, Card, Accordion } from 'react-bootstrap';
import './AyudaPage.css';

export const AyudaPage = () => {
  return (
    <div className="ayuda-page">
      <div className="page-header mb-4">
        <h1>Centro de Ayuda</h1>
        <p className="text-muted">Encuentra respuestas a las preguntas frecuentes sobre el sistema</p>
      </div>

      <Row>
        <Col lg={8}>
          <Accordion defaultActiveKey="0" className="mb-4">
            <Accordion.Item eventKey="0">
              <Accordion.Header>¿Cómo registrar un nuevo estudiante?</Accordion.Header>
              <Accordion.Body>
                Para registrar un nuevo estudiante:
                <ol className="mt-3 mb-0">
                  <li>Ve a la sección "Estudiantes"</li>
                  <li>Haz clic en el botón "+ Nuevo Estudiante"</li>
                  <li>Completa los campos requeridos (cédula, nombre, email)</li>
                  <li>Asigna el curso y paralelo correspondiente</li>
                  <li>Sube una foto de perfil (opcional)</li>
                  <li>Haz clic en "Guardar"</li>
                </ol>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="1">
              <Accordion.Header>¿Cómo registrar notas?</Accordion.Header>
              <Accordion.Body>
                Para registrar una nueva nota:
                <ol className="mt-3 mb-0">
                  <li>Ve a la sección "Notas"</li>
                  <li>Haz clic en "+ Registrar Nueva Nota"</li>
                  <li>Selecciona el estudiante y asignatura</li>
                  <li>Selecciona el tipo de evaluación (tarea, informe, lección, examen)</li>
                  <li>Ingresa la calificación (0-20)</li>
                  <li>Añade observaciones si es necesario</li>
                  <li>Haz clic en "Guardar Nota"</li>
                </ol>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="2">
              <Accordion.Header>¿Cuál es la estructura de calificación por parcial?</Accordion.Header>
              <Accordion.Body>
                Cada parcial se compone de 4 evaluaciones:
                <table className="table table-sm mt-3">
                  <thead>
                    <tr>
                      <th>Evaluación</th>
                      <th>Porcentaje</th>
                      <th>Sobre</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Tarea</td>
                      <td>20%</td>
                      <td>20 puntos</td>
                    </tr>
                    <tr>
                      <td>Informe</td>
                      <td>20%</td>
                      <td>20 puntos</td>
                    </tr>
                    <tr>
                      <td>Lección</td>
                      <td>20%</td>
                      <td>20 puntos</td>
                    </tr>
                    <tr>
                      <td>Examen</td>
                      <td>40%</td>
                      <td>20 puntos</td>
                    </tr>
                  </tbody>
                </table>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="3">
              <Accordion.Header>¿Qué significa "Reprobado Anticipado"?</Accordion.Header>
              <Accordion.Body>
                Un estudiante se considera "Reprobado Anticipado" cuando la suma del Parcial 1 + Parcial 2 es menor
                a 28 puntos. Esto significa que automáticamente no puede aprobar el semestre.
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="4">
              <Accordion.Header>¿Cómo se calcula la nota final del semestre?</Accordion.Header>
              <Accordion.Body>
                La nota final del semestre se calcula sumando los tres parciales:
                <ul className="mt-3 mb-0">
                  <li>Cada parcial vale máximo 14 puntos</li>
                  <li>Nota máxima final: 42.10 puntos</li>
                  <li>El estudiante aprueba si obtiene 28 o más puntos en total</li>
                </ul>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="5">
              <Accordion.Header>¿Cómo editar o eliminar información?</Accordion.Header>
              <Accordion.Body>
                Para editar: Haz clic en el botón "Editar" en la fila del registro que deseas modificar y actualiza los
                datos.
                <br />
                <br />
                Para eliminar: Haz clic en el botón "Eliminar" y confirma la acción en el modal de confirmación. La
                eliminación es lógica, no se pierden los datos reales.
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="6">
              <Accordion.Header>¿Puedo buscar registros específicos?</Accordion.Header>
              <Accordion.Body>
                Sí. En cada sección encontrarás un campo de búsqueda o filtros avanzados:
                <ul className="mt-3 mb-0">
                  <li>Estudiantes: Busca por nombre, cédula o email</li>
                  <li>Docentes: Busca por nombre o área</li>
                  <li>Notas: Filtra por estudiante, docente, curso o asignatura</li>
                </ul>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        </Col>

        <Col lg={4}>
          <Card className="shadow-sm mb-3">
            <Card.Header className="bg-primary text-white">
              <h5 className="mb-0">📞 Contacto Soporte</h5>
            </Card.Header>
            <Card.Body>
              <p>
                <strong>Email:</strong>
                <br />
                soporte@institucion.edu
              </p>
              <p>
                <strong>Teléfono:</strong>
                <br />
                +593 2 XXX XXXX
              </p>
              <p>
                <strong>Horario:</strong>
                <br />
                Lunes a Viernes: 8:00 - 17:00
              </p>
            </Card.Body>
          </Card>

          <Card className="shadow-sm">
            <Card.Header className="bg-success text-white">
              <h5 className="mb-0">💡 Tips Útiles</h5>
            </Card.Header>
            <Card.Body>
              <ul className="tips-list">
                <li>Guarda regularmente tus cambios</li>
                <li>Verifica los datos antes de guardar</li>
                <li>Usa los filtros para encontrar rápidamente</li>
                <li>Las notas se calculan automáticamente</li>
                <li>Contacta al soporte ante problemas</li>
              </ul>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AyudaPage;
