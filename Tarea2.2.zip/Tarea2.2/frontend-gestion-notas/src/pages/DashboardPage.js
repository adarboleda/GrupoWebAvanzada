import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Button, Badge } from 'react-bootstrap';
import { useAuth } from '../context/AuthContext';
import './DashboardPage.css';

export const DashboardPage = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    estudiantes: 0,
    docentes: 0,
    notas: 0,
  });

  useEffect(() => {
    cargarEstadisticas();
  }, []);

  const cargarEstadisticas = async () => {
    try {
      const [resEst, resDoc, resNotas] = await Promise.all([
        fetch('http://localhost:3001/api/estudiantes'),
        fetch('http://localhost:3001/api/docentes'),
        fetch('http://localhost:3001/api/notas'),
      ]);

      let estudiantes = 0;
      let docentes = 0;
      let notas = 0;

      if (resEst.ok) {
        const estData = await resEst.json();
        estudiantes = Array.isArray(estData) ? estData.length : 0;
      }

      if (resDoc.ok) {
        const docData = await resDoc.json();
        docentes = Array.isArray(docData) ? docData.length : 0;
      }

      if (resNotas.ok) {
        const notasData = await resNotas.json();
        notas = Array.isArray(notasData) ? notasData.length : 0;
      }

      setStats({ estudiantes, docentes, notas });
    } catch (err) {
      console.error('Error cargando estadísticas:', err);
    }
  };

  const [actividades] = useState([
    {
      id: 1,
      tipo: 'estudiante',
      descripcion: 'Nuevo estudiante registrado: Juan Pérez',
      fecha: new Date(Date.now() - 3600000),
    },
    {
      id: 2,
      tipo: 'nota',
      descripcion: 'Calificación registrada para María García - Matemáticas',
      fecha: new Date(Date.now() - 7200000),
    },
    {
      id: 3,
      tipo: 'docente',
      descripcion: 'Docente actualizado: Carlos López - Nuevas asignaturas',
      fecha: new Date(Date.now() - 86400000),
    },
  ]);

  const [notificaciones] = useState([
    { id: 1, mensaje: '5 estudiantes necesitan calificación actualizada', tipo: 'warning' },
    { id: 2, mensaje: 'Parcial 2 finaliza en 7 días', tipo: 'info' },
    { id: 3, mensaje: '3 docentes con documentación pendiente', tipo: 'danger' },
  ]);

  const [proximos] = useState([
    { id: 1, evento: 'Cierre de Parcial 1', fecha: '2025-12-20' },
    { id: 2, evento: 'Inicio de Parcial 2', fecha: '2025-12-21' },
    { id: 3, evento: 'Reunión de Docentes', fecha: '2025-12-25' },
  ]);

  const formatearFecha = (fecha) => {
    const ahora = new Date();
    const diferencia = ahora - fecha;
    const minutos = Math.floor(diferencia / 60000);

    if (minutos < 60) return `Hace ${minutos} minuto${minutos !== 1 ? 's' : ''}`;
    if (minutos < 1440) return `Hace ${Math.floor(minutos / 60)} hora${Math.floor(minutos / 60) !== 1 ? 's' : ''}`;
    return `Hace ${Math.floor(minutos / 1440)} día${Math.floor(minutos / 1440) !== 1 ? 's' : ''}`;
  };

  return (
    <div className="dashboard-page">
      <div className="welcome-section mb-4">
        <h1>Bienvenido, {user?.email}</h1>
        <p className="text-muted">Panel de control del sistema de gestión de notas</p>
      </div>

      <Row className="mb-5">
        <Col lg={4} md={6} className="mb-3">
          <Card className="stats-card shadow-sm">
            <Card.Body className="text-center">
              <div className="stats-icon">👨‍🎓</div>
              <h5>{stats.estudiantes}</h5>
              <p className="text-muted">Estudiantes Registrados</p>
            </Card.Body>
          </Card>
        </Col>
        <Col lg={4} md={6} className="mb-3">
          <Card className="stats-card shadow-sm">
            <Card.Body className="text-center">
              <div className="stats-icon">👨‍🏫</div>
              <h5>{stats.docentes}</h5>
              <p className="text-muted">Docentes Registrados</p>
            </Card.Body>
          </Card>
        </Col>
        <Col lg={4} md={6} className="mb-3">
          <Card className="stats-card shadow-sm">
            <Card.Body className="text-center">
              <div className="stats-icon">📊</div>
              <h5>{stats.notas}</h5>
              <p className="text-muted">Notas Registradas</p>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="mb-4">
        <Col lg={6} className="mb-3">
          <Card className="shadow-sm">
            <Card.Header className="bg-primary text-white">
              <h5 className="mb-0">📅 Últimas Actividades</h5>
            </Card.Header>
            <Card.Body>
              <div className="activities-list">
                {actividades.map((actividad) => (
                  <div key={actividad.id} className="activity-item mb-3 pb-3 border-bottom">
                    <div className="d-flex justify-content-between">
                      <p className="mb-1">{actividad.descripcion}</p>
                      <Badge bg="info">{actividad.tipo}</Badge>
                    </div>
                    <small className="text-muted">{formatearFecha(actividad.fecha)}</small>
                  </div>
                ))}
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={6} className="mb-3">
          <Card className="shadow-sm">
            <Card.Header className="bg-warning text-dark">
              <h5 className="mb-0">🔔 Notificaciones Recientes</h5>
            </Card.Header>
            <Card.Body>
              <div className="notifications-list">
                {notificaciones.map((notif) => (
                  <div key={notif.id} className="notification-item mb-3 pb-3 border-bottom">
                    <div className="alert alert-light mb-0 d-flex justify-content-between align-items-center">
                      <span>{notif.mensaje}</span>
                      <Badge bg={notif.tipo}>Nuevo</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row>
        <Col lg={6} className="mb-3">
          <Card className="shadow-sm">
            <Card.Header className="bg-success text-white">
              <h5 className="mb-0">📆 Próximos Eventos</h5>
            </Card.Header>
            <Card.Body>
              <div className="eventos-list">
                {proximos.map((evento) => (
                  <div key={evento.id} className="evento-item mb-3 pb-3 border-bottom">
                    <div className="d-flex justify-content-between align-items-center">
                      <span className="fw-bold">{evento.evento}</span>
                      <Badge bg="success">{evento.fecha}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={6} className="mb-3">
          <Card className="shadow-sm">
            <Card.Header className="bg-secondary text-white">
              <h5 className="mb-0">⚡ Acciones Rápidas</h5>
            </Card.Header>
            <Card.Body>
              <div className="d-grid gap-2">
                <Button variant="outline-primary" href="/estudiantes">
                  Gestionar Estudiantes
                </Button>
                <Button variant="outline-info" href="/docentes">
                  Gestionar Docentes
                </Button>
                <Button variant="outline-success" href="/notas">
                  Registrar Notas
                </Button>
                <Button variant="outline-warning" href="/ayuda">
                  Ver Ayuda
                </Button>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default DashboardPage;
