// Funciones para calcular notas según la lógica académica

/**
 * Estructura de un parcial:
 * - Tarea: 20% sobre 20 puntos
 * - Informe: 20% sobre 20 puntos
 * - Lección: 20% sobre 20 puntos
 * - Examen: 40% sobre 20 puntos
 */

export const calcularNotaParcial = (evaluaciones) => {
  if (!evaluaciones || evaluaciones.length === 0) return 0;

  const tarea = evaluaciones.find((e) => e.tipo === 'tarea')?.nota || 0;
  const informe = evaluaciones.find((e) => e.tipo === 'informe')?.nota || 0;
  const leccion = evaluaciones.find((e) => e.tipo === 'leccion')?.nota || 0;
  const examen = evaluaciones.find((e) => e.tipo === 'examen')?.nota || 0;

  // Cada nota se calcula sobre 20 puntos
  const notaTarea = (tarea / 20) * 20 * 0.2; // 20% de tarea
  const notaInforme = (informe / 20) * 20 * 0.2; // 20% de informe
  const notaLeccion = (leccion / 20) * 20 * 0.2; // 20% de lección
  const notaExamen = (examen / 20) * 20 * 0.4; // 40% de examen

  const notaFinal = notaTarea + notaInforme + notaLeccion + notaExamen;
  return parseFloat(notaFinal.toFixed(2));
};

/**
 * Calcular nota final del semestre a partir de 3 parciales
 * Cada parcial vale 14 puntos (14 * 3 = 42)
 * Máximo: 42.10 puntos
 */
export const calcularNotaSemestre = (parciales) => {
  if (!parciales || parciales.length === 0) return 0;

  // Cada parcial vale máximo 14 puntos
  const suma = parciales.reduce((acc, p) => {
    const nota = Math.min(p, 14);
    return acc + nota;
  }, 0);

  return parseFloat(suma.toFixed(2));
};

/**
 * Verificar si el estudiante reprobó anticipadamente
 * Condición: P1 + P2 < 28
 */
export const verificarReproboAnticipado = (parcial1, parcial2) => {
  return parcial1 + parcial2 < 28;
};

/**
 * Determinar estado académico del estudiante
 */
export const determinarEstadoAcademico = (parciales) => {
  if (parciales.length < 2) {
    return { estado: 'pendiente', razon: 'Faltan parciales por calificar' };
  }

  const p1 = parciales[0];
  const p2 = parciales[1];

  // Verificar reprobación anticipada
  if (verificarReproboAnticipado(p1, p2)) {
    return { estado: 'reprobado_anticipado', razon: 'P1 + P2 < 28' };
  }

  if (parciales.length === 3) {
    const p3 = parciales[2];
    const notaSemestre = calcularNotaSemestre([p1, p2, p3]);

    if (notaSemestre >= 28) {
      return { estado: 'aprobado_semestre', razon: `Nota final: ${notaSemestre}` };
    } else {
      return { estado: 'reprobado_semestre', razon: `Nota final: ${notaSemestre}` };
    }
  }

  return { estado: 'en_proceso', razon: 'Parciales en curso' };
};

/**
 * Validar que una nota sea válida (0-20)
 */
export const validarNota = (nota) => {
  const n = parseFloat(nota);
  return !isNaN(n) && n >= 0 && n <= 20;
};

/**
 * Formatear nota a 2 decimales
 */
export const formatearNota = (nota) => {
  return parseFloat(nota).toFixed(2);
};
