import React, { useState, useEffect } from 'react';
import { Form, Button, Row, Col } from 'react-bootstrap';
import { validarNota } from '../../utils/notasCalc';
import { estudiantesService } from '../../api/estudiantesService';
import { docentesService } from '../../api/docentesService';

const NotaForm = ({ onGuardar, onCancelar, data }) => {
  const [formData, setFormData] = useState(
    data || {
      estudianteId: '',
      estudianteNombre: '',
      cedula: '',
      asignatura: '',
      docenteId: '',
      docenteNombre: '',
      parcial: '1',
      tipoEvaluacion: 'tarea',
      nota: '',
      observaciones: '',
      fechaEvaluacion: new Date().toISOString().split('T')[0],
    }
  );

  const [estudiantes, setEstudiantes] = useState([]);
  const [docentes, setDocentes] = useState([]);
  const [errors, setErrors] = useState({});
  const [loadingData, setLoadingData] = useState(false);

  const tiposEvaluacion = [
    { value: 'tarea', label: 'Tarea' },
    { value: 'informe', label: 'Informe' },
    { value: 'leccion', label: 'Lección' },
    { value: 'participacion', label: 'Participación' },
    { value: 'proyecto', label: 'Proyecto' },
    { value: 'examen', label: 'Examen' },
  ];
  const asignaturas = [
    'Cálculo I',
    'Programación I',
    'Español I',
    'Física General',
    'Química I',
    'Historia del Ecuador',
    'Educación Física',
    'Inglés Básico',
    'Lógica Matemática',
    'Introdución a la Informática'
  ];
  const parciales = ['1', '2', '3'];

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    try {
      setLoadingData(true);
      const [estData, docData] = await Promise.all([
        estudiantesService.obtenerEstudiantes(),
        docentesService.obtenerDocentes(),
      ]);
      setEstudiantes(estData);
      setDocentes(docData);
    } catch (err) {
      console.error('Error cargando datos:', err);
    } finally {
      setLoadingData(false);
    }
  };

  const validar = () => {
    const nuevosErrores = {};
    if (!formData.estudianteId.trim()) nuevosErrores.estudianteId = 'Estudiante es requerido';
    if (!formData.asignatura.trim()) nuevosErrores.asignatura = 'Asignatura es requerida';
    if (!formData.docenteId.trim()) nuevosErrores.docenteId = 'Docente es requerido';
    if (!formData.nota) nuevosErrores.nota = 'Nota es requerida';
    if (!validarNota(formData.nota)) nuevosErrores.nota = 'Nota debe estar entre 0 y 20';
    if (!formData.fechaEvaluacion) nuevosErrores.fechaEvaluacion = 'Fecha es requerida';

    setErrors(nuevosErrores);
    return Object.keys(nuevosErrores).length === 0;
  };

  const handleEstudianteChange = (e) => {
    const estudianteId = e.target.value;
    const estudiante = estudiantes.find(e => e._id === estudianteId);
    setFormData((prev) => ({
      ...prev,
      estudianteId,
      estudianteNombre: estudiante?.nombre || '',
      cedula: estudiante?.cedula || '',
    }));
    if (errors.estudianteId) setErrors((prev) => ({ ...prev, estudianteId: '' }));
  };

  const handleDocenteChange = (e) => {
    const docenteId = e.target.value;
    const docente = docentes.find(d => d._id === docenteId);
    setFormData((prev) => ({
      ...prev,
      docenteId,
      docenteNombre: docente?.nombre || '',
    }));
    if (errors.docenteId) setErrors((prev) => ({ ...prev, docenteId: '' }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validar()) {
      onGuardar({ ...formData, nota: parseFloat(formData.nota) });
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      
      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Estudiante *</Form.Label>
            <Form.Select
              name="estudianteId"
              value={formData.estudianteId}
              onChange={handleEstudianteChange}
              isInvalid={!!errors.estudianteId}
              disabled={loadingData}
            >
              <option value="">Seleccionar estudiante...</option>
              {estudiantes.map((est) => (
                <option key={est._id} value={est._id}>
                  {est.nombre} ({est.cedula})
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">{errors.estudianteId}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Cédula</Form.Label>
            <Form.Control
              type="text"
              value={formData.cedula}
              readOnly
              disabled
              className="bg-light"
            />
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Asignatura *</Form.Label>
            <Form.Select
              name="asignatura"
              value={formData.asignatura}
              onChange={handleChange}
              isInvalid={!!errors.asignatura}
            >
              <option value="">Seleccionar asignatura...</option>
              {asignaturas.map((asig) => (
                <option key={asig} value={asig}>
                  {asig}
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">{errors.asignatura}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Docente *</Form.Label>
            <Form.Select
              name="docenteId"
              value={formData.docenteId}
              onChange={handleDocenteChange}
              isInvalid={!!errors.docenteId}
              disabled={loadingData}
            >
              <option value="">Seleccionar docente...</option>
              {docentes.map((doc) => (
                <option key={doc._id} value={doc._id}>
                  {doc.nombre}
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">{errors.docenteId}</Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={3}>
          <Form.Group className="mb-3">
            <Form.Label>Parcial *</Form.Label>
            <Form.Select name="parcial" value={formData.parcial} onChange={handleChange}>
              {parciales.map((p) => (
                <option key={p} value={p}>
                  Parcial {p}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={5}>
          <Form.Group className="mb-3">
            <Form.Label>Tipo de Evaluación *</Form.Label>
            <Form.Select 
              name="tipoEvaluacion" 
              value={formData.tipoEvaluacion} 
              onChange={handleChange}
            >
              {tiposEvaluacion.map((tipo) => (
                <option key={tipo.value} value={tipo.value}>
                  {tipo.label}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={4}>
          <Form.Group className="mb-3">
            <Form.Label>Nota (0-20) *</Form.Label>
            <Form.Control
              type="number"
              name="nota"
              value={formData.nota}
              onChange={handleChange}
              isInvalid={!!errors.nota}
              min="0"
              max="20"
              step="0.1"
              placeholder="0.00"
            />
            <Form.Control.Feedback type="invalid">{errors.nota}</Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

      <Form.Group className="mb-3">
        <Form.Label>Fecha de Evaluación *</Form.Label>
        <Form.Control
          type="date"
          name="fechaEvaluacion"
          value={formData.fechaEvaluacion}
          onChange={handleChange}
          isInvalid={!!errors.fechaEvaluacion}
        />
        <Form.Control.Feedback type="invalid">{errors.fechaEvaluacion}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Observaciones</Form.Label>
        <Form.Control
          as="textarea"
          name="observaciones"
          value={formData.observaciones}
          onChange={handleChange}
          rows={3}
          placeholder="Observaciones del docente (opcional)"
        />
      </Form.Group>

      <div className="d-grid gap-2 d-md-flex justify-content-md-end">
        <Button variant="secondary" onClick={onCancelar}>
          Cancelar
        </Button>
        <Button variant="primary" type="submit" disabled={loadingData}>
          {loadingData ? 'Cargando...' : 'Guardar Nota'}
        </Button>
      </div>
    </Form>
  );
};

export default NotaForm;
