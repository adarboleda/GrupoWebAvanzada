import React, { useState, useEffect } from 'react';
import { Row, Col, Button, Form, Spinner, Alert, Modal, Card, Badge, Table } from 'react-bootstrap';
import { determinarEstadoAcademico, formatearNota } from '../../utils/notasCalc';
import NotaForm from './NotaForm';
import './NotasPage.css';

export const NotasPage = () => {
  const [notas, setNotas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editingData, setEditingData] = useState(null);
  const [filtro, setFiltro] = useState({
    estudiante: '',
    docente: '',
    curso: '',
    asignatura: '',
  });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [viewMode, setViewMode] = useState('lista');

  useEffect(() => {
    cargarNotas();
  }, []);

  const cargarNotas = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await fetch('http://localhost:3001/api/notas');
      if (data.ok) {
        const notas = await data.json();
        setNotas(notas);
      }
    } catch (err) {
      setError('Error al cargar notas: ' + (err.message || 'Intente nuevamente'));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGuardar = async (data) => {
    try {
      setError('');
      if (editingId) {
        const response = await fetch(`http://localhost:3001/api/notas/${editingId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (response.ok) {
          const notaActualizada = await response.json();
          setSuccess('✓ Nota actualizada correctamente');
          setNotas(
            notas.map((n) => (n._id === editingId ? notaActualizada : n))
          );
        }
      } else {
        const response = await fetch('http://localhost:3001/api/notas', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (response.ok) {
          const nuevaNota = await response.json();
          setSuccess('✓ Nota registrada correctamente');
          setNotas([...notas, nuevaNota]);
        }
      }
      setShowForm(false);
      setEditingId(null);
      setEditingData(null);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('✗ Error al guardar nota: ' + (err.message || 'Intente nuevamente'));
      console.error(err);
    }
  };

  const handleEditar = (nota) => {
    setEditingId(nota._id);
    setEditingData(nota);
    setShowForm(true);
  };

  const handleEliminar = async () => {
    try {
      setError('');
      const response = await fetch(`http://localhost:3001/api/notas/${deleteId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        setSuccess('✓ Nota eliminada correctamente');
        setNotas(notas.filter((n) => n._id !== deleteId));
        setShowDeleteModal(false);
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError('Error al eliminar nota');
      console.error(err);
    }
  };

  const handleCancelar = () => {
    setShowForm(false);
    setEditingId(null);
    setEditingData(null);
  };

  const notasFiltered = notas.filter(
    (n) =>
      (!filtro.estudiante || n.estudianteNombre?.toLowerCase().includes(filtro.estudiante.toLowerCase())) &&
      (!filtro.docente || n.docenteNombre?.toLowerCase().includes(filtro.docente.toLowerCase())) &&
      (!filtro.asignatura || n.asignatura?.toLowerCase().includes(filtro.asignatura.toLowerCase()))
  );

  return (
    <div className="notas-page">
      <div className="page-header mb-4">
        <h1>Gestión de Notas</h1>
        <p className="text-muted">Administra y registra las calificaciones de estudiantes</p>
      </div>

      {error && <Alert variant="danger" onClose={() => setError('')} dismissible>{error}</Alert>}
      {success && <Alert variant="success" onClose={() => setSuccess('')} dismissible>{success}</Alert>}

      <div className="mb-4 d-flex gap-2">
        <Button
          variant={viewMode === 'lista' ? 'primary' : 'outline-primary'}
          onClick={() => setViewMode('lista')}
        >
          📋 Vista Lista
        </Button>
        <Button
          variant={viewMode === 'resumen' ? 'primary' : 'outline-primary'}
          onClick={() => setViewMode('resumen')}
        >
          📊 Vista Resumen
        </Button>
      </div>

      {viewMode === 'lista' ? (
        <>
          <div className="filters-section mb-4 p-3 bg-light rounded">
            <Row>
              <Col md={3}>
                <Form.Group>
                  <Form.Label>Estudiante</Form.Label>
                  <Form.Control
                    placeholder="Buscar estudiante..."
                    value={filtro.estudiante}
                    onChange={(e) =>
                      setFiltro({ ...filtro, estudiante: e.target.value })
                    }
                  />
                </Form.Group>
              </Col>
              <Col md={3}>
                <Form.Group>
                  <Form.Label>Docente</Form.Label>
                  <Form.Control
                    placeholder="Buscar docente..."
                    value={filtro.docente}
                    onChange={(e) =>
                      setFiltro({ ...filtro, docente: e.target.value })
                    }
                  />
                </Form.Group>
              </Col>
              <Col md={3}>
                <Form.Group>
                  <Form.Label>Curso/Paralelo</Form.Label>
                  <Form.Control
                    placeholder="Buscar curso..."
                    value={filtro.curso}
                    onChange={(e) =>
                      setFiltro({ ...filtro, curso: e.target.value })
                    }
                  />
                </Form.Group>
              </Col>
              <Col md={3}>
                <Form.Group>
                  <Form.Label>Asignatura</Form.Label>
                  <Form.Control
                    placeholder="Buscar asignatura..."
                    value={filtro.asignatura}
                    onChange={(e) =>
                      setFiltro({ ...filtro, asignatura: e.target.value })
                    }
                  />
                </Form.Group>
              </Col>
            </Row>
          </div>

          <div className="mb-4">
            <Button
              variant="success"
              onClick={() => {
                setEditingId(null);
                setEditingData(null);
                setShowForm(true);
              }}
              className="w-100"
            >
              + Registrar Nueva Nota
            </Button>
          </div>

          {loading ? (
            <div className="text-center py-5">
              <Spinner animation="border" role="status">
                <span className="visually-hidden">Cargando...</span>
              </Spinner>
            </div>
          ) : notasFiltered.length === 0 ? (
            <div className="alert alert-info text-center py-5">
              <p className="mb-0">No hay notas registradas</p>
            </div>
          ) : (
            <div className="table-responsive">
              <Table hover className="notas-table">
                <thead>
                  <tr>
                    <th>Estudiante</th>
                    <th>Cédula</th>
                    <th>Asignatura</th>
                    <th>Docente</th>
                    <th>Tipo</th>
                    <th>Nota</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {notasFiltered.map((nota) => (
                    <tr key={nota._id}>
                      <td className="fw-bold">{nota.estudianteNombre}</td>
                      <td>{nota.cedula}</td>
                      <td>{nota.asignatura}</td>
                      <td>{nota.docenteNombre}</td>
                      <td>
                        <Badge bg="info">{nota.tipoEvaluacion}</Badge>
                      </td>
                      <td>
                        <span className={`nota-badge ${nota.nota >= 14 ? 'success' : nota.nota >= 10 ? 'warning' : 'danger'}`}>
                          {formatearNota(nota.nota)}/20
                        </span>
                      </td>
                      <td>{new Date(nota.fechaEvaluacion).toLocaleDateString('es-ES')}</td>
                      <td>
                        <Button
                          variant="outline-primary"
                          size="sm"
                          onClick={() => handleEditar(nota)}
                          className="me-2"
                        >
                          ✏️ Editar
                        </Button>
                        <Button
                          variant="outline-danger"
                          size="sm"
                          onClick={() => {
                            setDeleteId(nota._id);
                            setShowDeleteModal(true);
                          }}
                        >
                          🗑️ Eliminar
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          )}
        </>
      ) : (
        <ResumenNotas notas={notas} />
      )}

      {/* Modal de confirmación de eliminación */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmar eliminación</Modal.Title>
        </Modal.Header>
        <Modal.Body>¿Está seguro de que desea eliminar esta nota? Esta acción no se puede deshacer.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancelar
          </Button>
          <Button variant="danger" onClick={handleEliminar}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Modal del formulario */}
      <Modal show={showForm} onHide={handleCancelar} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Nota' : 'Registrar Nueva Nota'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <NotaForm onGuardar={handleGuardar} onCancelar={handleCancelar} data={editingData} />
        </Modal.Body>
      </Modal>
    </div>
  );
};

// Componente para vista de resumen
const ResumenNotas = ({ notas }) => {
  const notasPorEstudiante = {};
  notas.forEach((nota) => {
    if (!notasPorEstudiante[nota.estudiante]) {
      notasPorEstudiante[nota.estudiante] = [];
    }
    notasPorEstudiante[nota.estudiante].push(nota);
  });

  return (
    <Row>
      {Object.entries(notasPorEstudiante).map(([estudiante, notasEst]) => {
        const estado = determinarEstadoAcademico([]);
        return (
          <Col lg={6} key={estudiante} className="mb-4">
            <Card className="shadow-sm">
              <Card.Header className="bg-primary text-white">
                <h5 className="mb-0">{estudiante}</h5>
              </Card.Header>
              <Card.Body>
                <div className="mb-3">
                  <Badge bg={estado.estado.includes('aprobado') ? 'success' : 'danger'}>
                    {estado.estado}
                  </Badge>
                </div>
                <Table size="sm" striped>
                  <tbody>
                    {notasEst.map((nota, idx) => (
                      <tr key={idx}>
                        <td>{nota.asignatura}</td>
                        <td className="text-end">
                          <strong>{formatearNota(nota.nota)}/20</strong>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Card.Body>
            </Card>
          </Col>
        );
      })}
    </Row>
  );
};

export default NotasPage;
