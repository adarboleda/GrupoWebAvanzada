import React from 'react';
import { Table, Button, Badge } from 'react-bootstrap';

const DocentesList = ({ docentes, onEditar, onEliminar }) => {
  if (docentes.length === 0) {
    return (
      <div className="alert alert-info text-center py-5">
        <p className="mb-0">No hay docentes registrados</p>
      </div>
    );
  }

  return (
    <div className="table-responsive">
      <Table hover className="docentes-table">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Cédula</th>
            <th>Email</th>
            <th>Área</th>
            <th>Carga Horaria</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {docentes.map((docente) => (
            <tr key={docente._id}>
              <td className="fw-bold">{docente.nombre}</td>
              <td>{docente.cedula}</td>
              <td>{docente.email}</td>
              <td>{docente.area}</td>
              <td>{docente.cargaHoraria} h/sem</td>
              <td>
                <Badge bg={docente.estado === 'activo' ? 'success' : 'danger'}>
                  {docente.estado}
                </Badge>
              </td>
              <td>
                <Button
                  variant="outline-primary"
                  size="sm"
                  onClick={() => onEditar(docente)}
                  className="me-2"
                >
                  ✏️ Editar
                </Button>
                <Button
                  variant="outline-danger"
                  size="sm"
                  onClick={() => onEliminar(docente._id)}
                >
                  🗑️ Eliminar
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default DocentesList;
