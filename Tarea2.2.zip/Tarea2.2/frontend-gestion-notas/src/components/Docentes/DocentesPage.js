import React, { useState, useEffect } from 'react';
import { Row, Col, Button, Form, Spinner, Alert, Modal } from 'react-bootstrap';
import DocenteForm from './DocenteForm';
import DocentesList from './DocentesList';
import './DocentesPage.css';

export const DocentesPage = () => {
  const [docentes, setDocentes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editingData, setEditingData] = useState(null);
  const [busqueda, setBusqueda] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  useEffect(() => {
    cargarDocentes();
  }, []);

  const cargarDocentes = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await fetch('http://localhost:3001/api/docentes');
      if (response.ok) {
        const data = await response.json();
        setDocentes(data);
      }
    } catch (err) {
      setError('Error al cargar docentes');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGuardar = async (data) => {
    try {
      setError('');
      if (editingId) {
        const response = await fetch(`http://localhost:3001/api/docentes/${editingId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (response.ok) {
          const docenteActualizado = await response.json();
          setSuccess('✓ Docente actualizado correctamente');
          setDocentes(
            docentes.map((d) => (d._id === editingId ? docenteActualizado : d))
          );
        }
      } else {
        const response = await fetch('http://localhost:3001/api/docentes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (response.ok) {
          const nuevoDocente = await response.json();
          setSuccess('✓ Docente creado correctamente');
          setDocentes([...docentes, nuevoDocente]);
        }
      }
      setShowForm(false);
      setEditingId(null);
      setEditingData(null);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('✗ Error al guardar docente: ' + (err.message || 'Intente nuevamente'));
      console.error(err);
    }
  };

  const handleEditar = (docente) => {
    setEditingId(docente._id);
    setEditingData(docente);
    setShowForm(true);
  };

  const handleEliminar = async () => {
    try {
      setError('');
      const response = await fetch(`http://localhost:3001/api/docentes/${deleteId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        setSuccess('✓ Docente eliminado correctamente');
        setDocentes(docentes.filter((d) => d._id !== deleteId));
        setShowDeleteModal(false);
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError('Error al eliminar docente');
      console.error(err);
    }
  };

  const handleCancelar = () => {
    setShowForm(false);
    setEditingId(null);
    setEditingData(null);
  };

  const docentesFiltered = docentes.filter(
    (d) =>
      d.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      d.cedula?.includes(busqueda) ||
      d.email?.toLowerCase().includes(busqueda.toLowerCase())
  );

  return (
    <div className="docentes-page">
      <div className="page-header mb-4">
        <h1>Gestión de Docentes</h1>
        <p className="text-muted">Administra la información de los docentes del sistema</p>
      </div>

      {error && <Alert variant="danger" onClose={() => setError('')} dismissible>{error}</Alert>}
      {success && <Alert variant="success" onClose={() => setSuccess('')} dismissible>{success}</Alert>}

      <Row className="mb-4">
        <Col md={8}>
          <Form.Control
            placeholder="Buscar por nombre, cédula o email..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="search-input"
          />
        </Col>
        <Col md={4} className="text-end">
          <Button
            variant="primary"
            onClick={() => {
              setEditingId(null);
              setEditingData(null);
              setShowForm(true);
            }}
            className="w-100"
          >
            + Nuevo Docente
          </Button>
        </Col>
      </Row>

      {loading ? (
        <div className="text-center py-5">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Cargando...</span>
          </Spinner>
        </div>
      ) : (
        <DocentesList
          docentes={docentesFiltered}
          onEditar={handleEditar}
          onEliminar={(id) => {
            setDeleteId(id);
            setShowDeleteModal(true);
          }}
        />
      )}

      {/* Modal de confirmación de eliminación */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmar eliminación</Modal.Title>
        </Modal.Header>
        <Modal.Body>¿Está seguro de que desea eliminar este docente? Esta acción no se puede deshacer.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancelar
          </Button>
          <Button variant="danger" onClick={handleEliminar}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Modal del formulario */}
      <Modal show={showForm} onHide={handleCancelar} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Docente' : 'Nuevo Docente'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <DocenteForm onGuardar={handleGuardar} onCancelar={handleCancelar} data={editingData} />
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default DocentesPage;
