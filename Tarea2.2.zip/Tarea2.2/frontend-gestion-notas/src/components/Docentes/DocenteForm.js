import React, { useState } from 'react';
import { Form, Button, Row, Col } from 'react-bootstrap';

const DocenteForm = ({ onGuardar, onCancelar, data }) => {
  const [formData, setFormData] = useState(
    data || {
      nombre: '',
      email: '',
      cedula: '',
      especialidad: '',
      area: '',
      cargaHoraria: '',
      telefono: '',
      estado: 'activo',
      materias: [],
    }
  );

  const [errors, setErrors] = useState({});

  // Opciones para los selects
  const areas = [
    'Matemáticas',
    'Lenguaje y Literatura',
    'Ciencias Naturales',
    'Estudios Sociales',
    'Educación Física',
    'Idioma Extranjero',
    'Informática',
    'Artes Plásticas',
    'Música',
    'Filosofía'
  ];

  const especialidades = [
    'Álgebra',
    'Geometría',
    'Cálculo',
    'Estadística',
    'Gramática',
    'Literatura',
    'Redacción',
    'Biología',
    'Química',
    'Física',
    'Historia',
    'Geografía',
    'Educación Cívica',
    'Deportes',
    'Inglés',
    'Francés',
    'Programación',
    'Base de Datos',
    'Pintura',
    'Escultura',
    'Canto',
    'Ética'
  ];

  const materiasDisponibles = [
    'Cálculo I',
    'Programación I',
    'Español I',
    'Física General',
    'Química I',
    'Historia del Ecuador',
    'Educación Física',
    'Inglés Básico',
    'Lógica Matemática',
    'Introdución a la Informática',
    'Álgebra Lineal',
    'Geometría Analítica',
    'Literatura Universal',
    'Redacción Académica',
    'Estadística Descriptiva',
    'Biología Celular',
    'Fundamentos de Redes',
  ];

  const cargasHorarias = ['20h', '30h', '40h', '50h'];

  const validar = () => {
    const nuevosErrores = {};
    if (!formData.nombre.trim()) nuevosErrores.nombre = 'Nombre es requerido';
    if (!formData.email.trim()) nuevosErrores.email = 'Email es requerido';
    if (!/\S+@\S+\.\S+/.test(formData.email)) nuevosErrores.email = 'Email inválido';
    if (!formData.cedula.trim()) nuevosErrores.cedula = 'Cédula es requerida';
    if (!formData.area.trim()) nuevosErrores.area = 'Área es requerida';
    setErrors(nuevosErrores);
    return Object.keys(nuevosErrores).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleMateriasChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, option => option.value);
    setFormData((prev) => ({ ...prev, materias: selectedOptions }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validar()) {
      // Convertir cargaHoraria a número, extrayendo solo los dígitos
      const cargaHorariaNum = formData.cargaHoraria ? parseInt(formData.cargaHoraria) : null;
      onGuardar({
        ...formData,
        cargaHoraria: cargaHorariaNum
      });
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Nombre Completo</Form.Label>
            <Form.Control
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleChange}
              isInvalid={!!errors.nombre}
            />
            <Form.Control.Feedback type="invalid">{errors.nombre}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Cédula</Form.Label>
            <Form.Control
              type="text"
              name="cedula"
              value={formData.cedula}
              onChange={handleChange}
              isInvalid={!!errors.cedula}
            />
            <Form.Control.Feedback type="invalid">{errors.cedula}</Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              isInvalid={!!errors.email}
            />
            <Form.Control.Feedback type="invalid">{errors.email}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Teléfono</Form.Label>
            <Form.Control
              type="tel"
              name="telefono"
              value={formData.telefono}
              onChange={handleChange}
            />
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Área *</Form.Label>
            <Form.Select
              name="area"
              value={formData.area}
              onChange={handleChange}
              isInvalid={!!errors.area}
            >
              <option value="">Seleccionar área...</option>
              {areas.map((area) => (
                <option key={area} value={area}>
                  {area}
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">{errors.area}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Especialidad</Form.Label>
            <Form.Select
              name="especialidad"
              value={formData.especialidad}
              onChange={handleChange}
            >
              <option value="">Seleccionar especialidad...</option>
              {especialidades.map((esp) => (
                <option key={esp} value={esp}>
                  {esp}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Carga Horaria (horas/semana)</Form.Label>
            <Form.Select
              name="cargaHoraria"
              value={formData.cargaHoraria}
              onChange={handleChange}
            >
              <option value="">Seleccionar carga horaria...</option>
              {cargasHorarias.map((carga) => (
                <option key={carga} value={carga}>
                  {carga}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Estado</Form.Label>
            <Form.Select name="estado" value={formData.estado} onChange={handleChange}>
              <option value="activo">Activo</option>
              <option value="inactivo">Inactivo</option>
            </Form.Select>
          </Form.Group>
        </Col>
      </Row>

      <Form.Group className="mb-3">
        <Form.Label>Materias Asignadas</Form.Label>
        <Form.Select
          multiple
          name="materias"
          value={Array.isArray(formData.materias) ? formData.materias : []}
          onChange={handleMateriasChange}
          size={5}
        >
          {materiasDisponibles.map((materia) => (
            <option key={materia} value={materia}>
              {materia}
            </option>
          ))}
        </Form.Select>
        <Form.Text className="text-muted d-block mt-2">
          Usa Ctrl+Click (Cmd+Click en Mac) para seleccionar múltiples materias
        </Form.Text>
      </Form.Group>

      <div className="d-grid gap-2 d-md-flex justify-content-md-end">
        <Button variant="secondary" onClick={onCancelar}>
          ✕ Cancelar
        </Button>
        <Button variant="primary" type="submit">
          ✓ Guardar
        </Button>
      </div>
    </Form>
  );
};

export default DocenteForm;
