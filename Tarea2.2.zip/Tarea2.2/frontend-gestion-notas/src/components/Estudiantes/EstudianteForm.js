import React, { useState } from 'react';
import { Form, Button, Row, Col } from 'react-bootstrap';

const EstudianteForm = ({ onGuardar, onCancelar, data }) => {
  const [formData, setFormData] = useState(
    data ? {
      cedula: data.cedula || '',
      nombre: data.nombre || '',
      email: data.email || '',
      telefono: data.telefono || '',
      direccion: data.direccion || '',
      curso: data.curso || '',
      paralelo: data.paralelo || 'A',
      estado: data.estado || 'activo',
      foto: data.foto || '',
    } : {
      cedula: '',
      nombre: '',
      email: '',
      telefono: '',
      direccion: '',
      curso: '',
      paralelo: 'A',
      estado: 'activo',
      foto: '',
    }
  );

  const [errors, setErrors] = useState({});

  const validar = () => {
    const nuevosErrores = {};
    if (!formData.cedula.trim()) nuevosErrores.cedula = 'Cédula es requerida';
    if (!formData.nombre.trim()) nuevosErrores.nombre = 'Nombre es requerido';
    if (!formData.email.trim()) nuevosErrores.email = 'Email es requerido';
    if (!/\S+@\S+\.\S+/.test(formData.email)) nuevosErrores.email = 'Email inválido';
    if (!formData.curso.trim()) nuevosErrores.curso = 'Curso es requerido';
    setErrors(nuevosErrores);
    return Object.keys(nuevosErrores).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validar()) {
      onGuardar(formData);
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Cédula</Form.Label>
            <Form.Control
              type="text"
              name="cedula"
              value={formData.cedula}
              onChange={handleChange}
              isInvalid={!!errors.cedula}
            />
            <Form.Control.Feedback type="invalid">{errors.cedula}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Nombre Completo</Form.Label>
            <Form.Control
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={handleChange}
              isInvalid={!!errors.nombre}
            />
            <Form.Control.Feedback type="invalid">{errors.nombre}</Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              isInvalid={!!errors.email}
            />
            <Form.Control.Feedback type="invalid">{errors.email}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Teléfono</Form.Label>
            <Form.Control
              type="tel"
              name="telefono"
              value={formData.telefono}
              onChange={handleChange}
            />
          </Form.Group>
        </Col>
      </Row>

      <Form.Group className="mb-3">
        <Form.Label>Dirección</Form.Label>
        <Form.Control
          type="text"
          name="direccion"
          value={formData.direccion}
          onChange={handleChange}
        />
      </Form.Group>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Curso</Form.Label>
            <Form.Control
              type="text"
              name="curso"
              value={formData.curso}
              onChange={handleChange}
              isInvalid={!!errors.curso}
              placeholder="Ej: 2do A"
            />
            <Form.Control.Feedback type="invalid">{errors.curso}</Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Paralelo</Form.Label>
            <Form.Select name="paralelo" value={formData.paralelo} onChange={handleChange}>
              <option>A</option>
              <option>B</option>
              <option>C</option>
            </Form.Select>
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Estado</Form.Label>
            <Form.Select name="estado" value={formData.estado} onChange={handleChange}>
              <option value="activo">Activo</option>
              <option value="inactivo">Inactivo</option>
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>URL Foto</Form.Label>
            <Form.Control
              type="url"
              name="foto"
              value={formData.foto}
              onChange={handleChange}
              placeholder="https://..."
            />
          </Form.Group>
        </Col>
      </Row>

      <div className="d-grid gap-2 d-md-flex justify-content-md-end">
        <Button variant="secondary" onClick={onCancelar}>
          ✕ Cancelar
        </Button>
        <Button variant="primary" type="submit">
          ✓ Guardar
        </Button>
      </div>
    </Form>
  );
};

export default EstudianteForm;
