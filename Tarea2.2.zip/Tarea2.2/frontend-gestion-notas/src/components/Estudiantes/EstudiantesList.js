import React from 'react';
import { Table, Button, Badge, Image } from 'react-bootstrap';
import './EstudiantesPage.css';

const EstudiantesList = ({ estudiantes, onEditar, onEliminar }) => {
  if (estudiantes.length === 0) {
    return (
      <div className="alert alert-info text-center py-5">
        <p className="mb-0">No hay estudiantes registrados</p>
      </div>
    );
  }

  return (
    <div className="table-responsive">
      <Table hover className="estudiantes-table">
        <thead>
          <tr>
            <th>Foto</th>
            <th>Nombre</th>
            <th>Cédula</th>
            <th>Email</th>
            <th>Curso</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {estudiantes.map((estudiante) => (
            <tr key={estudiante._id}>
              <td>
                {estudiante.foto ? (
                  <Image src={estudiante.foto} alt={estudiante.nombre} rounded width="40" height="40" />
                ) : (
                  <img 
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${estudiante.cedula || estudiante._id}`}
                    alt={estudiante.nombre}
                    width="40"
                    height="40"
                    style={{ borderRadius: '50%' }}
                  />
                )}
              </td>
              <td className="fw-bold">{estudiante.nombre}</td>
              <td>{estudiante.cedula}</td>
              <td>{estudiante.email}</td>
              <td>{estudiante.curso}</td>
              <td>
                <Badge bg={estudiante.estado === 'activo' ? 'success' : 'danger'}>
                  {estudiante.estado}
                </Badge>
              </td>
              <td>
                <Button
                  variant="outline-primary"
                  size="sm"
                  onClick={() => onEditar(estudiante)}
                  className="me-2"
                >
                  ✏️ Editar
                </Button>
                <Button
                  variant="outline-danger"
                  size="sm"
                  onClick={() => onEliminar(estudiante._id)}
                >
                  🗑️ Eliminar
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default EstudiantesList;
