import React, { useState, useEffect } from 'react';
import { Row, Col, Button, Form, Spinner, Alert, Modal } from 'react-bootstrap';
import EstudianteForm from './EstudianteForm';
import EstudiantesList from './EstudiantesList';
import './EstudiantesPage.css';

export const EstudiantesPage = () => {
  const [estudiantes, setEstudiantes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editingData, setEditingData] = useState(null);
  const [busqueda, setBusqueda] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  useEffect(() => {
    cargarEstudiantes();
  }, []);

  const cargarEstudiantes = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Cargar desde DummyJSON
      const responseDummy = await fetch('https://dummyjson.com/users');
      const dataDummy = await responseDummy.json();
      const estudiantesFormateados = dataDummy.users.map(user => ({
        _id: user.id.toString(),
        id: user.id,
        nombre: `${user.firstName} ${user.lastName}`,
        email: user.email,
        cedula: user.phone,
        telefono: user.phone,
        direccion: `${user.address.address}, ${user.address.city}`,
        curso: '1ro',
        paralelo: user.id % 4 === 0 ? 'A' : user.id % 4 === 1 ? 'B' : user.id % 4 === 2 ? 'C' : 'D',
        estado: 'activo',
        foto: user.image,
        fuente: 'dummyjson'
      }));

      // Cargar desde MongoDB (Backend Local)
      let estudiantesMongo = [];
      try {
        const responseMongo = await fetch('http://localhost:3001/api/estudiantes');
        if (responseMongo.ok) {
          estudiantesMongo = await responseMongo.json();
          estudiantesMongo = estudiantesMongo.map(e => ({
            ...e,
            fuente: 'mongodb'
          }));
        }
      } catch (err) {
        console.log('MongoDB no disponible, continuando solo con DummyJSON');
      }

      // Combinar ambas listas (MongoDB + DummyJSON)
      const todosEstudiantes = [...estudiantesMongo, ...estudiantesFormateados];
      setEstudiantes(todosEstudiantes);
    } catch (err) {
      setError('Error al cargar estudiantes');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGuardar = async (data) => {
    try {
      setError('');
      if (editingId) {
        // Actualizar en MongoDB
        const response = await fetch(`http://localhost:3001/api/estudiantes/${editingId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (response.ok) {
          const estudianteActualizado = await response.json();
          setSuccess('✓ Estudiante actualizado correctamente');
          setEstudiantes(
            estudiantes.map((e) => (e._id === editingId ? estudianteActualizado : e))
          );
        }
      } else {
        // Crear en MongoDB
        const response = await fetch('http://localhost:3001/api/estudiantes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        if (response.ok) {
          const nuevoEstudiante = await response.json();
          setSuccess('✓ Estudiante creado correctamente');
          setEstudiantes([...estudiantes, nuevoEstudiante]);
        }
      }
      setShowForm(false);
      setEditingId(null);
      setEditingData(null);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('✗ Error al guardar estudiante: ' + (err.message || 'Intente nuevamente'));
      console.error(err);
    }
  };

  const handleEditar = (estudiante) => {
    setEditingId(estudiante._id);
    setEditingData(estudiante);
    setShowForm(true);
  };

  const handleEliminar = async () => {
    try {
      setError('');
      const response = await fetch(`http://localhost:3001/api/estudiantes/${deleteId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        setSuccess('✓ Estudiante eliminado correctamente');
        setEstudiantes(estudiantes.filter((e) => e._id !== deleteId));
        setShowDeleteModal(false);
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError('Error al eliminar estudiante');
      console.error(err);
    }
  };

  const handleCancelar = () => {
    setShowForm(false);
    setEditingId(null);
    setEditingData(null);
  };

  const estudiantesFiltered = estudiantes.filter(
    (e) =>
      e.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      e.cedula.includes(busqueda) ||
      e.email.toLowerCase().includes(busqueda.toLowerCase())
  );

  return (
    <div className="estudiantes-page">
      <div className="page-header mb-4">
        <h1>Gestión de Estudiantes</h1>
        <p className="text-muted">Administra la información de los estudiantes del sistema</p>
      </div>

      {error && <Alert variant="danger" onClose={() => setError('')} dismissible>{error}</Alert>}
      {success && <Alert variant="success" onClose={() => setSuccess('')} dismissible>{success}</Alert>}

      <Row className="mb-4">
        <Col md={8}>
          <Form.Control
            placeholder="Buscar por nombre, cédula o email..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="search-input"
          />
        </Col>
        <Col md={4} className="text-end">
          <Button
            variant="primary"
            onClick={() => {
              setEditingId(null);
              setEditingData(null);
              setShowForm(true);
            }}
            className="w-100"
          >
            + Nuevo Estudiante
          </Button>
        </Col>
      </Row>

      {loading ? (
        <div className="text-center py-5">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Cargando...</span>
          </Spinner>
        </div>
      ) : (
        <EstudiantesList
          estudiantes={estudiantesFiltered}
          onEditar={handleEditar}
          onEliminar={(id) => {
            setDeleteId(id);
            setShowDeleteModal(true);
          }}
        />
      )}

      {/* Modal de confirmación de eliminación */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmar eliminación</Modal.Title>
        </Modal.Header>
        <Modal.Body>¿Está seguro de que desea eliminar este estudiante? Esta acción no se puede deshacer.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancelar
          </Button>
          <Button variant="danger" onClick={handleEliminar}>
            Eliminar
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Modal del formulario */}
      <Modal show={showForm} onHide={handleCancelar} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{editingId ? 'Editar Estudiante' : 'Nuevo Estudiante'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <EstudianteForm onGuardar={handleGuardar} onCancelar={handleCancelar} data={editingData} />
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default EstudiantesPage;
