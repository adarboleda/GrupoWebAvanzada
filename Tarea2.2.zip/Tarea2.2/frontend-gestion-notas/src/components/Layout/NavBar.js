import React from 'react';
import { Navbar, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Layout.css';

export const NavBar = ({ onMenuToggle }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <Navbar bg="dark" sticky="top" className="navbar-custom">
      <Container fluid>
        <Navbar.Brand as={Link} to="/dashboard" className="d-flex align-items-center gap-2">
          <span className="brand-icon">📚</span>
          <span>Gestión Notas</span>
        </Navbar.Brand>
        
        <div className="d-flex align-items-center gap-3 ms-auto">
          <span className="user-info text-light">{user?.email}</span>
          <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>
            Cerrar Sesión
          </button>
        </div>
      </Container>
    </Navbar>
  );
};
