import React, { useState } from 'react';
import { Container, Offcanvas } from 'react-bootstrap';
import { NavBar } from './NavBar';
import './Layout.css';

export const Layout = ({ children }) => {
  const [showSidebar, setShowSidebar] = useState(false);

  const menuItems = [
    { path: '/dashboard', label: 'Inicio', icon: 'bi-house' },
    { path: '/estudiantes', label: 'Estudiantes', icon: 'bi-people' },
    { path: '/docentes', label: 'Docentes', icon: 'bi-briefcase' },
    { path: '/notas', label: 'Notas', icon: 'bi-file-earmark-text' },
    { path: '/ayuda', label: 'Ayuda', icon: 'bi-question-circle' }
  ];

  const handleCloseSidebar = () => setShowSidebar(false);

  return (
    <div className="layout-container">
      <NavBar onMenuToggle={() => setShowSidebar(true)} />
      
      {/* Sidebar Mobile */}
      <Offcanvas show={showSidebar} onHide={handleCloseSidebar} placement="start">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Menú Principal</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <nav className="sidebar-menu">
            {menuItems.map(item => (
              <a 
                key={item.path} 
                href={item.path} 
                className="sidebar-link"
                onClick={handleCloseSidebar}
              >
                <i className={`bi ${item.icon}`}></i>
                <span>{item.label}</span>
              </a>
            ))}
          </nav>
        </Offcanvas.Body>
      </Offcanvas>

      {/* Main Content */}
      <div className="layout-content">
        <aside className="sidebar-desktop">
          <div className="sidebar-header">
            <i className="bi bi-list"></i>
            <h6>Menú</h6>
          </div>
          <nav className="sidebar-menu">
            {menuItems.map(item => (
              <a 
                key={item.path} 
                href={item.path} 
                className="sidebar-link"
              >
                <i className={`bi ${item.icon}`}></i>
                <span>{item.label}</span>
              </a>
            ))}
          </nav>
        </aside>

        <Container fluid className="main-content py-4">
          {children}
        </Container>
      </div>

      <footer className="app-footer">
        <p>&copy; 2025 Sistema de Gestión de Notas Académicas</p>
      </footer>
    </div>
  );
};
