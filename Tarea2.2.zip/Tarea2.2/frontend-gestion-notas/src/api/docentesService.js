import axios from 'axios';

const LOCAL_API = 'http://localhost:3001/api/docentes';

export const docentesService = {
  // Obtener todos los docentes
  obtenerDocentes: async () => {
    try {
      const response = await axios.get(LOCAL_API);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Obtener un docente por ID
  obtenerDocente: async (id) => {
    try {
      const response = await axios.get(`${LOCAL_API}/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Crear un nuevo docente
  crearDocente: async (docente) => {
    try {
      const response = await axios.post(LOCAL_API, docente);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Actualizar un docente
  actualizarDocente: async (id, docente) => {
    try {
      const response = await axios.put(`${LOCAL_API}/${id}`, docente);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Eliminar un docente (eliminación lógica)
  eliminarDocente: async (id) => {
    try {
      const response = await axios.delete(`${LOCAL_API}/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Buscar docente por nombre, ID o área
  buscarDocente: async (criterio) => {
    try {
      const response = await axios.get(`${LOCAL_API}/buscar?criterio=${criterio}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },
};
