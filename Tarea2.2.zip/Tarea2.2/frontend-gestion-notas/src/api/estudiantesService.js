import axios from 'axios';

const DUMMYJSON_API = 'https://dummyjson.com/users';
const LOCAL_API = 'http://localhost:3001/api/estudiantes';

export const estudiantesService = {
  // Obtener estudiantes desde DummyJSON
  obtenerEstudiantesDummyJSON: async () => {
    try {
      const response = await axios.get(DUMMYJSON_API);
      // Mapear datos de DummyJSON al formato necesario
      return response.data.users.map((user) => ({
        id: user.id,
        cedula: `${user.id.toString().padStart(10, '0')}`,
        nombre: `${user.firstName} ${user.lastName}`,
        email: user.email,
        telefono: user.phone,
        direccion: `${user.address.address}, ${user.address.city}`,
        curso: 'Sin asignar',
        paralelo: 'A',
        estado: 'activo',
        foto: user.image,
      }));
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Obtener todos los estudiantes del backend local
  obtenerEstudiantes: async () => {
    try {
      const response = await axios.get(LOCAL_API);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Obtener un estudiante por ID
  obtenerEstudiante: async (id) => {
    try {
      const response = await axios.get(`${LOCAL_API}/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Crear un nuevo estudiante
  crearEstudiante: async (estudiante) => {
    try {
      const response = await axios.post(LOCAL_API, estudiante);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Actualizar un estudiante
  actualizarEstudiante: async (id, estudiante) => {
    try {
      const response = await axios.put(`${LOCAL_API}/${id}`, estudiante);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Eliminar un estudiante (eliminación lógica)
  eliminarEstudiante: async (id) => {
    try {
      const response = await axios.delete(`${LOCAL_API}/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Buscar estudiante por cédula, nombre o ID
  buscarEstudiante: async (criterio) => {
    try {
      const response = await axios.get(`${LOCAL_API}/buscar?criterio=${criterio}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },
};
