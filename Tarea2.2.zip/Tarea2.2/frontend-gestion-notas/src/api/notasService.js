import axios from 'axios';

const LOCAL_API = 'http://localhost:3001/api/notas';

export const notasService = {
  // Obtener todas las notas
  obtenerNotas: async (filtros = {}) => {
    try {
      const response = await axios.get(LOCAL_API, { params: filtros });
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Obtener una nota por ID
  obtenerNota: async (id) => {
    try {
      const response = await axios.get(`${LOCAL_API}/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Crear una nueva nota
  crearNota: async (nota) => {
    try {
      const response = await axios.post(LOCAL_API, nota);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Actualizar una nota
  actualizarNota: async (id, nota) => {
    try {
      const response = await axios.put(`${LOCAL_API}/${id}`, nota);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Eliminar una nota (eliminación lógica)
  eliminarNota: async (id) => {
    try {
      const response = await axios.delete(`${LOCAL_API}/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Obtener notas por estudiante
  obtenerNotasPorEstudiante: async (estudianteId) => {
    try {
      const response = await axios.get(`${LOCAL_API}/estudiante/${estudianteId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Obtener notas por docente
  obtenerNotasPorDocente: async (docenteId) => {
    try {
      const response = await axios.get(`${LOCAL_API}/docente/${docenteId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Calcular promedio de notas
  calcularPromedio: async (notas) => {
    if (!notas || notas.length === 0) return 0;
    const suma = notas.reduce((acc, nota) => acc + nota, 0);
    return (suma / notas.length).toFixed(2);
  },

  // Verificar si estudiante reprobó anticipadamente
  verificarReproboAnticipado: async (estudianteId) => {
    try {
      const response = await axios.get(`${LOCAL_API}/estudiante/${estudianteId}/reprobado-anticipado`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },
};
