# Backend - Sistema de Gestión de Notas

Backend Node.js + Express + MongoDB para el Sistema de Gestión de Notas Académicas.

## 🚀 Inicio Rápido

### 1. Instalar Dependencias

```bash
npm install
```

### 2. Configurar Variables de Entorno

Crea un archivo `.env` en la raíz del proyecto:

```env
PORT=3001
MONGODB_URI=mongodb://localhost:27017/GestionNotas
JWT_SECRET=tu_secreto_super_seguro_aqui_2025
NODE_ENV=development
```

### 3. Iniciar MongoDB

```bash
# En Windows
mongod

# O si tienes MongoDB como servicio
net start MongoDB
```

### 4. Ejecutar el Servidor

**Desarrollo con auto-reload:**
```bash
npm run dev
```

**Producción:**
```bash
npm start
```

El servidor estará disponible en `http://localhost:3001`

## 📁 Estructura del Proyecto

```
backend-gestion-notas/
├── app.js                          # Archivo principal
├── package.json
├── .env                            # Variables de entorno
└── src/
    ├── config/
    │   └── mongo.js               # Configuración de MongoDB
    ├── controllers/
    │   ├── estudianteController.js
    │   ├── docenteController.js
    │   └── notaController.js
    ├── models/
    │   ├── Estudiante.js
    │   ├── Docente.js
    │   └── Nota.js
    └── routes/
        ├── estudiante.routes.js
        ├── docente.routes.js
        └── nota.routes.js
```

## 🔌 Endpoints API

### Estudiantes

```
GET    /api/estudiantes              # Listar todos (activos)
POST   /api/estudiantes              # Crear
GET    /api/estudiantes/buscar       # Buscar por criterio
GET    /api/estudiantes/:id          # Obtener uno
PUT    /api/estudiantes/:id          # Actualizar
DELETE /api/estudiantes/:id          # Eliminar (lógica)
```

**Ejemplo POST Estudiante:**
```json
{
  "cedula": "1234567890",
  "nombre": "Juan Pérez García",
  "email": "juan@ejemplo.com",
  "telefono": "0987654321",
  "direccion": "Calle Principal 123",
  "curso": "2do A",
  "paralelo": "A",
  "foto": "https://ejemplo.com/foto.jpg"
}
```

### Docentes

```
GET    /api/docentes                 # Listar todos (activos)
POST   /api/docentes                 # Crear
GET    /api/docentes/buscar          # Buscar por criterio
GET    /api/docentes/:id             # Obtener uno
PUT    /api/docentes/:id             # Actualizar
DELETE /api/docentes/:id             # Eliminar (lógica)
```

**Ejemplo POST Docente:**
```json
{
  "cedula": "9876543210",
  "nombre": "Carlos López",
  "email": "carlos@institucion.edu",
  "telefono": "0987654321",
  "area": "Matemáticas",
  "especialidad": "Álgebra",
  "cargaHoraria": 30,
  "materias": ["Álgebra", "Geometría"]
}
```

### Notas

```
GET    /api/notas                    # Listar todas (con filtros)
POST   /api/notas                    # Crear
GET    /api/notas/:id                # Obtener una
PUT    /api/notas/:id                # Actualizar
DELETE /api/notas/:id                # Eliminar (lógica)
GET    /api/notas/estudiante/:id     # Por estudiante
GET    /api/notas/docente/:id        # Por docente
GET    /api/notas/calcular/promedio  # Calcular promedio
```

**Ejemplo POST Nota:**
```json
{
  "estudianteNombre": "Juan Pérez",
  "cedula": "1234567890",
  "docenteNombre": "Carlos López",
  "asignatura": "Matemáticas",
  "curso": "2do A",
  "paralelo": "A",
  "parcial": 1,
  "tipoEvaluacion": "examen",
  "nota": 18,
  "observaciones": "Excelente rendimiento",
  "fecha": "2025-12-10"
}
```

### Filtros y Parámetros

**GET /api/notas:**
```
?estudiante=Juan&docente=Carlos&curso=2do&asignatura=Matemáticas&parcial=1&ordenar=mayor
```

Opciones de `ordenar`: `mayor`, `menor`, `reciente`

## 📊 Modelos de Datos

### Estudiante
```javascript
{
  _id: ObjectId,
  cedula: String (unique),
  nombre: String,
  email: String (unique),
  telefono: String,
  direccion: String,
  curso: String,
  paralelo: String (A|B|C|D),
  estado: String (activo|inactivo),
  foto: String (URL),
  fechaIngreso: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Docente
```javascript
{
  _id: ObjectId,
  cedula: String (unique),
  nombre: String,
  email: String (unique),
  telefono: String,
  area: String,
  especialidad: String,
  cargaHoraria: Number,
  materias: [String],
  estado: String (activo|inactivo),
  fechaIngreso: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Nota
```javascript
{
  _id: ObjectId,
  estudiante: ObjectId,
  estudianteNombre: String,
  cedula: String,
  docente: ObjectId,
  docenteNombre: String,
  asignatura: String,
  curso: String,
  paralelo: String,
  parcial: Number (1|2|3),
  tipoEvaluacion: String (tarea|informe|leccion|examen),
  nota: Number (0-20),
  porcentaje: Number,
  aporte: Number,
  observaciones: String,
  fecha: Date,
  estado: String (activo|inactivo),
  registradoPor: String,
  createdAt: Date,
  updatedAt: Date
}
```

## 🧪 Pruebas con cURL

```bash
# Listar estudiantes
curl http://localhost:3001/api/estudiantes

# Crear estudiante
curl -X POST http://localhost:3001/api/estudiantes \
  -H "Content-Type: application/json" \
  -d '{
    "cedula": "1234567890",
    "nombre": "Juan Pérez",
    "email": "juan@ejemplo.com",
    "curso": "2do A"
  }'

# Listar notas con filtro
curl "http://localhost:3001/api/notas?estudiante=Juan&parcial=1"

# Actualizar nota
curl -X PUT http://localhost:3001/api/notas/{id} \
  -H "Content-Type: application/json" \
  -d '{
    "nota": 19,
    "observaciones": "Excelente"
  }'
```

## 🛡️ Manejo de Errores

La API devuelve códigos de estado HTTP estándar:

- **200 OK** - Solicitud exitosa
- **201 Created** - Recurso creado
- **400 Bad Request** - Datos inválidos
- **404 Not Found** - Recurso no encontrado
- **500 Internal Server Error** - Error del servidor

## 📝 Validaciones

### Estudiante
- Cédula requerida y única
- Email requerido, único y válido
- Nombre requerido
- Curso requerido
- Paralelo: A, B, C, D

### Docente
- Cédula requerida y única
- Email requerido, único y válido
- Nombre requerido
- Área requerida

### Nota
- Estudianteombre requerido
- Asignatura requerida
- Curso requerido
- Parcial: 1, 2 o 3
- Tipo Evaluación: tarea, informe, leccion, examen
- Nota: 0-20
- Tipo Evaluación define automáticamente el porcentaje

## 🔄 Lógica de Cálculo de Notas

```
Aporte = (Nota / 20) × (Porcentaje / 100) × 20

Ejemplo:
- Nota: 18
- Tipo: Examen (40%)
- Aporte = (18/20) × (40/100) × 20 = 7.2

Promedio Parcial = Suma de Aportes
Nota Final Semestre = P1 + P2 + P3 (máx 42.10)
```

## 🔐 Seguridad

- Validación de entrada en todos los endpoints
- Eliminación lógica de datos
- CORS habilitado
- Variables de entorno sensibles

## 📊 Base de Datos

### Índices (Automáticos)
- Estudiante: cedula, email (unique)
- Docente: cedula, email (unique)
- Nota: estudiante, docente, parcial

### Conexión MongoDB

La aplicación se conecta automáticamente a MongoDB al iniciar. Asegúrate de que:

1. MongoDB está corriendo
2. La URI en `.env` es correcta
3. La base de datos existe o será creada automáticamente

## 🚨 Troubleshooting

### Error de conexión a MongoDB
```
Solución: Asegúrate de que MongoDB está corriendo
mongod
```

### Puerto 3001 en uso
```
Solución: Cambia el puerto en .env o detén el servicio anterior
```

### Errores de validación
```
Solución: Verifica que todos los campos requeridos se envíen
```

## 📚 Recursos Adicionales

- [Documentación Express](https://expressjs.com/)
- [Documentación Mongoose](https://mongoosejs.com/)
- [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) (MongoDB en la nube)

## 👨‍💻 Desarrollo

El proyecto utiliza `nodemon` para auto-recargar en cambios de código.

```bash
npm run dev
```

---

**Versión**: 1.0.0  
**Última actualización**: Diciembre 2025
