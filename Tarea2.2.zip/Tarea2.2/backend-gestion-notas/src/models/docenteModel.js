import mongoose from 'mongoose';

const DocenteSchema = new mongoose.Schema(
  {
    cedula: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    nombre: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    telefono: {
      type: String,
      trim: true,
    },
    area: {
      type: String,
      required: true, // Ej: Matemáticas, Lenguaje, etc.
      trim: true,
    },
    especialidad: {
      type: String,
      trim: true,
    },
    cargaHoraria: {
      type: Number, // horas por semana
      min: 0,
    },
    materias: [
      {
        type: String,
      },
    ],
    estado: {
      type: String,
      default: 'activo',
      enum: ['activo', 'inactivo'],
    },
    fechaIngreso: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

export const Docente = mongoose.model('Docente', DocenteSchema);
