import mongoose from 'mongoose';

const EstudianteSchema = new mongoose.Schema(
  {
    cedula: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    nombre: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    telefono: {
      type: String,
      trim: true,
    },
    direccion: {
      type: String,
      trim: true,
    },
    curso: {
      type: String,
      required: true,
      trim: true,
    },
    paralelo: {
      type: String,
      default: 'A',
      enum: ['A', 'B', 'C', 'D'],
    },
    estado: {
      type: String,
      default: 'activo',
      enum: ['activo', 'inactivo'],
    },
    foto: {
      type: String, // URL de la imagen
      default: null,
    },
    fechaIngreso: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

export const Estudiante = mongoose.model('Estudiante', EstudianteSchema);
