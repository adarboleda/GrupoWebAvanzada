import mongoose from 'mongoose';

const NotaSchema = new mongoose.Schema(
  {
    estudiante: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Estudiante',
      required: true,
    },
    estudianteNombre: {
      type: String,
      required: true,
    },
    cedula: {
      type: String,
      required: true,
    },
    docente: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Docente',
    },
    docenteNombre: {
      type: String,
    },
    asignatura: {
      type: String,
      required: true,
      trim: true,
    },
    curso: {
      type: String,
      required: true,
    },
    paralelo: {
      type: String,
      default: 'A',
    },
    parcial: {
      type: Number,
      required: true,
      enum: [1, 2, 3],
    },
    tipoEvaluacion: {
      type: String,
      required: true,
      enum: ['tarea', 'informe', 'leccion', 'participacion', 'proyecto', 'examen'],
    },
    nota: {
      type: Number,
      required: true,
      min: 0,
      max: 20,
    },
    porcentaje: {
      type: Number,
      default: function() {
        const porcentajes = {
          tarea: 20,
          informe: 20,
          leccion: 20,
          examen: 40,
        };
        return porcentajes[this.tipoEvaluacion] || 0;
      },
    },
    aporte: {
      type: Number,
      default: function() {
        return (this.nota / 20) * (this.porcentaje / 100) * 20;
      },
    },
    observaciones: {
      type: String,
      trim: true,
    },
    fechaEvaluacion: {
      type: Date,
      required: true,
      default: Date.now,
    },
    estado: {
      type: String,
      default: 'activo',
      enum: ['activo', 'inactivo'],
    },
    registradoPor: {
      type: String, // Email del docente que registró
    },
  },
  { timestamps: true }
);

export const Nota = mongoose.model('Nota', NotaSchema);
