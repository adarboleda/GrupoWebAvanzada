import mongoose from 'mongoose';

const usuarioSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    nombre: {
      type: String,
      required: true,
    },
    rol: {
      type: String,
      enum: ['estudiante', 'docente', 'admin'],
      required: true,
    },
    estado: {
      type: String,
      enum: ['activo', 'inactivo'],
      default: 'activo',
    },
  },
  {
    timestamps: true,
  }
);

export const Usuario = mongoose.model('Usuario', usuarioSchema);
