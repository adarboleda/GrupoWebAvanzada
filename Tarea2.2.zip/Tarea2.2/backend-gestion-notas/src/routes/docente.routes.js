import express from 'express';
import {
  obtenerDocentes,
  obtenerDocente,
  crearDocente,
  actualizarDocente,
  eliminarDocente,
  buscarDocente,
} from '../controllers/docenteController.js';

const router = express.Router();

// CRUD
router.get('/', obtenerDocentes);
router.post('/', crearDocente);
router.get('/buscar', buscarDocente);
router.get('/:id', obtenerDocente);
router.put('/:id', actualizarDocente);
router.delete('/:id', eliminarDocente);

export default router;
