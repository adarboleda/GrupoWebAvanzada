import express from 'express';
import {
  obtenerEstudiantes,
  obtenerEstudiante,
  crearEstudiante,
  actualizarEstudiante,
  eliminarEstudiante,
  buscarEstudiante,
} from '../controllers/estudianteController.js';

const router = express.Router();

// CRUD
router.get('/', obtenerEstudiantes);
router.post('/', crearEstudiante);
router.get('/buscar', buscarEstudiante);
router.get('/:id', obtenerEstudiante);
router.put('/:id', actualizarEstudiante);
router.delete('/:id', eliminarEstudiante);

export default router;
