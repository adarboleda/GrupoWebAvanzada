import express from 'express';
import {
  obtenerNotas,
  obtenerNota,
  crearNota,
  actualizarNota,
  eliminarNota,
  obtenerNotasPorEstudiante,
  obtenerNotasPorDocente,
  calcularPromedioParcial,
} from '../controllers/notaController.js';

const router = express.Router();

// CRUD
router.get('/', obtenerNotas);
router.post('/', crearNota);
router.get('/calcular/promedio', calcularPromedioParcial);
router.get('/estudiante/:estudianteId', obtenerNotasPorEstudiante);
router.get('/docente/:docenteId', obtenerNotasPorDocente);
router.get('/:id', obtenerNota);
router.put('/:id', actualizarNota);
router.delete('/:id', eliminarNota);

export default router;
