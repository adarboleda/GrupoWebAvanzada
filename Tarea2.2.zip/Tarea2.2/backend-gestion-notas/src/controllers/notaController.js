import { Nota } from '../models/notaModel.js';

// Obtener todas las notas
export const obtenerNotas = async (req, res) => {
  try {
    const { estudiante, docente, curso, asignatura, parcial, ordenar } = req.query;
    let filtro = { estado: 'activo' };

    if (estudiante) filtro.estudianteNombre = { $regex: estudiante, $options: 'i' };
    if (docente) filtro.docenteNombre = { $regex: docente, $options: 'i' };
    if (curso) filtro.curso = { $regex: curso, $options: 'i' };
    if (asignatura) filtro.asignatura = { $regex: asignatura, $options: 'i' };
    if (parcial) filtro.parcial = parseInt(parcial);

    let query = Nota.find(filtro);

    // Ordenamiento
    if (ordenar === 'mayor') {
      query = query.sort({ nota: -1 });
    } else if (ordenar === 'menor') {
      query = query.sort({ nota: 1 });
    } else if (ordenar === 'reciente') {
      query = query.sort({ createdAt: -1 });
    } else {
      query = query.sort({ createdAt: -1 });
    }

    const notas = await query;
    res.json(notas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener una nota por ID
export const obtenerNota = async (req, res) => {
  try {
    const nota = await Nota.findById(req.params.id);
    if (!nota) {
      return res.status(404).json({ error: 'Nota no encontrada' });
    }
    res.json(nota);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Crear nueva nota
export const crearNota = async (req, res) => {
  try {
    const { estudianteId, estudianteNombre, cedula, docenteId, docenteNombre, asignatura, parcial, tipoEvaluacion, nota, observaciones, fechaEvaluacion } = req.body;

    if (!estudianteNombre || !cedula || !asignatura || !parcial || !tipoEvaluacion || nota === undefined) {
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    }

    if (nota < 0 || nota > 20) {
      return res.status(400).json({ error: 'La nota debe estar entre 0 y 20' });
    }

    const nuevaNota = new Nota({
      estudiante: estudianteId,
      estudianteNombre,
      cedula,
      docente: docenteId,
      docenteNombre: docenteNombre || 'Sin asignar',
      asignatura,
      parcial: parseInt(parcial),
      tipoEvaluacion,
      nota: parseFloat(nota),
      observaciones,
      fechaEvaluacion: fechaEvaluacion || new Date(),
      estado: 'activo',
    });

    await nuevaNota.save();
    res.status(201).json(nuevaNota);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Actualizar nota
export const actualizarNota = async (req, res) => {
  try {
    // Validar nota si se incluye en la actualización
    if (req.body.nota !== undefined && (req.body.nota < 0 || req.body.nota > 20)) {
      return res.status(400).json({ error: 'La nota debe estar entre 0 y 20' });
    }

    const nota = await Nota.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!nota) {
      return res.status(404).json({ error: 'Nota no encontrada' });
    }

    res.json(nota);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Eliminar nota (eliminación lógica)
export const eliminarNota = async (req, res) => {
  try {
    const nota = await Nota.findByIdAndUpdate(
      req.params.id,
      { estado: 'inactivo' },
      { new: true }
    );

    if (!nota) {
      return res.status(404).json({ error: 'Nota no encontrada' });
    }

    res.json({ message: 'Nota eliminada correctamente', nota });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener notas por estudiante
export const obtenerNotasPorEstudiante = async (req, res) => {
  try {
    const { estudianteId } = req.params;
    const notas = await Nota.find({
      estudiante: estudianteId,
      estado: 'activo',
    }).sort({ parcial: 1, tipoEvaluacion: 1 });

    res.json(notas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener notas por docente
export const obtenerNotasPorDocente = async (req, res) => {
  try {
    const { docenteId } = req.params;
    const notas = await Nota.find({
      docente: docenteId,
      estado: 'activo',
    }).sort({ createdAt: -1 });

    res.json(notas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Calcular promedio parcial
export const calcularPromedioParcial = async (req, res) => {
  try {
    const { estudianteId, parcial, asignatura } = req.query;

    if (!estudianteId || !parcial || !asignatura) {
      return res.status(400).json({ error: 'Se requieren estudianteId, parcial y asignatura' });
    }

    const notas = await Nota.find({
      estudiante: estudianteId,
      parcial: parseInt(parcial),
      asignatura,
      estado: 'activo',
    });

    if (notas.length === 0) {
      return res.json({ promedio: 0, notas: [] });
    }

    let promedio = 0;
    const aportesMap = {
      tarea: 0,
      informe: 0,
      leccion: 0,
      examen: 0,
    };

    notas.forEach((nota) => {
      const aporte = (nota.nota / 20) * (nota.porcentaje / 100) * 20;
      aportesMap[nota.tipoEvaluacion] = aporte;
    });

    promedio = Object.values(aportesMap).reduce((a, b) => a + b, 0);

    res.json({
      promedio: parseFloat(promedio.toFixed(2)),
      aportes: aportesMap,
      notas,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
