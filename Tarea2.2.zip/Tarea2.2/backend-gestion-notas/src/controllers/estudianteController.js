import { Estudiante } from '../models/estudianteModel.js';

export const obtenerEstudiantes = async (req, res) => {
  try {
    const estudiantes = await Estudiante.find({ estado: 'activo' }).sort({ createdAt: -1 });
    res.json(estudiantes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerEstudiante = async (req, res) => {
  try {
    const estudiante = await Estudiante.findById(req.params.id);
    if (!estudiante) {
      return res.status(404).json({ error: 'Estudiante no encontrado' });
    }
    res.json(estudiante);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const crearEstudiante = async (req, res) => {
  try {
    const { cedula, nombre, email, telefono, direccion, curso, paralelo, foto } = req.body;

    // Validar campos requeridos
    if (!cedula || !nombre || !email || !curso) {
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    }

    // Validar que cedula y email sean únicos
    const existente = await Estudiante.findOne({
      $or: [{ cedula }, { email }],
    });

    if (existente) {
      return res.status(400).json({ error: 'La cédula o email ya existe' });
    }

    const nuevoEstudiante = new Estudiante({
      cedula,
      nombre,
      email,
      telefono,
      direccion,
      curso,
      paralelo,
      foto,
    });

    await nuevoEstudiante.save();
    res.status(201).json(nuevoEstudiante);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarEstudiante = async (req, res) => {
  try {
    const estudiante = await Estudiante.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!estudiante) {
      return res.status(404).json({ error: 'Estudiante no encontrado' });
    }

    res.json(estudiante);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarEstudiante = async (req, res) => {
  try {
    // Eliminación lógica
    const estudiante = await Estudiante.findByIdAndUpdate(
      req.params.id,
      { estado: 'inactivo' },
      { new: true }
    );

    if (!estudiante) {
      return res.status(404).json({ error: 'Estudiante no encontrado' });
    }

    res.json({ message: 'Estudiante eliminado correctamente', estudiante });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const buscarEstudiante = async (req, res) => {
  try {
    const { criterio } = req.query;

    if (!criterio) {
      return res.status(400).json({ error: 'Se requiere un criterio de búsqueda' });
    }

    const estudiantes = await Estudiante.find({
      estado: 'activo',
      $or: [
        { nombre: { $regex: criterio, $options: 'i' } },
        { cedula: { $regex: criterio, $options: 'i' } },
        { email: { $regex: criterio, $options: 'i' } },
      ],
    });

    res.json(estudiantes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
