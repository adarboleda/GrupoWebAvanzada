import jwt from 'jsonwebtoken';
import { Usuario } from '../models/usuarioModel.js';

// Usuarios de prueba (como en OAuth)
const usuariosPrueba = [
  {
    email: 'admin@example.com',
    password: '1234',
    nombre: 'Administrador del Sistema',
    rol: 'admin',
  },
  {
    email: 'docente@example.com',
    password: 'abcd',
    nombre: 'Prof. Juan Pérez',
    rol: 'docente',
  },
  {
    email: 'estudiante@example.com',
    password: 'xyz',
    nombre: 'Carlos García',
    rol: 'estudiante',
  },
  {
    email: 'docente2@example.com',
    password: '5678',
    nombre: 'Dra. María López',
    rol: 'docente',
  },
  {
    email: 'estudiante2@example.com',
    password: 'pass123',
    nombre: 'Sofía Rodríguez',
    rol: 'estudiante',
  },
];

export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña son requeridos' });
    }

    // Verificar contra usuarios de prueba
    const usuarioPrueba = usuariosPrueba.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );

    if (!usuarioPrueba) {
      return res.status(401).json({ error: 'Email o contraseña incorrectos' });
    }

    // Generar JWT
    const token = jwt.sign(
      {
        email: usuarioPrueba.email,
        nombre: usuarioPrueba.nombre,
        rol: usuarioPrueba.rol,
      },
      process.env.JWT_SECRET || 'tu_secreto_super_seguro_aqui_2025',
      { expiresIn: '24h' }
    );

    res.json({
      ok: true,
      token,
      user: {
        email: usuarioPrueba.email,
        nombre: usuarioPrueba.nombre,
        rol: usuarioPrueba.rol,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const register = async (req, res) => {
  try {
    const { email, password, nombre, rol } = req.body;

    if (!email || !password || !nombre || !rol) {
      return res.status(400).json({
        error: 'Email, contraseña, nombre y rol son requeridos',
      });
    }

    // Validar rol
    if (!['estudiante', 'docente', 'admin'].includes(rol)) {
      return res.status(400).json({
        error: 'Rol inválido. Debe ser: estudiante, docente o admin',
      });
    }

    // Verificar si existe
    const existe = await Usuario.findOne({ email: email.toLowerCase() });
    if (existe) {
      return res.status(400).json({ error: 'El email ya está registrado' });
    }

    // Crear usuario
    const usuario = await Usuario.create({
      email: email.toLowerCase(),
      password,
      nombre,
      rol,
      estado: 'activo',
    });

    // Generar JWT
    const token = jwt.sign(
      {
        email: usuario.email,
        nombre: usuario.nombre,
        rol: usuario.rol,
      },
      process.env.JWT_SECRET || 'tu_secreto_super_seguro_aqui_2025',
      { expiresIn: '24h' }
    );

    res.status(201).json({
      ok: true,
      token,
      user: {
        email: usuario.email,
        nombre: usuario.nombre,
        rol: usuario.rol,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
