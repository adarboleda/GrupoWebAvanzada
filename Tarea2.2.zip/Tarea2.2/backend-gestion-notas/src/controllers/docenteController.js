import { Docente } from '../models/docenteModel.js';

// Obtener todos los docentes
export const obtenerDocentes = async (req, res) => {
  try {
    const docentes = await Docente.find({ estado: 'activo' }).sort({ createdAt: -1 });
    res.json(docentes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Obtener un docente por ID
export const obtenerDocente = async (req, res) => {
  try {
    const docente = await Docente.findById(req.params.id);
    if (!docente) {
      return res.status(404).json({ error: 'Docente no encontrado' });
    }
    res.json(docente);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Crear nuevo docente
export const crearDocente = async (req, res) => {
  try {
    const { cedula, nombre, email, telefono, area, especialidad, cargaHoraria, materias } = req.body;

    if (!cedula || !nombre || !email || !area) {
      return res.status(400).json({ error: 'Faltan campos requeridos' });
    }

    // Verificar que cedula sea única
    const existente = await Docente.findOne({ cedula });
    if (existente) {
      return res.status(400).json({ error: 'La cédula ya está registrada' });
    }

    const nuevoDocente = new Docente({
      cedula,
      nombre,
      email,
      telefono,
      area,
      especialidad,
      cargaHoraria,
      materias: materias || [],
      estado: 'activo',
    });

    await nuevoDocente.save();
    res.status(201).json(nuevoDocente);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Actualizar docente
export const actualizarDocente = async (req, res) => {
  try {
    const docente = await Docente.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!docente) {
      return res.status(404).json({ error: 'Docente no encontrado' });
    }

    res.json(docente);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Eliminar docente (eliminación lógica)
export const eliminarDocente = async (req, res) => {
  try {
    const docente = await Docente.findByIdAndUpdate(
      req.params.id,
      { estado: 'inactivo' },
      { new: true }
    );

    if (!docente) {
      return res.status(404).json({ error: 'Docente no encontrado' });
    }

    res.json({ message: 'Docente eliminado correctamente', docente });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Buscar docente por nombre, cedula o email
export const buscarDocente = async (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({ error: 'Se requiere parámetro de búsqueda' });
    }

    const docentes = await Docente.find({
      estado: 'activo',
      $or: [
        { nombre: { $regex: q, $options: 'i' } },
        { cedula: { $regex: q, $options: 'i' } },
        { email: { $regex: q, $options: 'i' } },
      ],
    });

    res.json(docentes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
