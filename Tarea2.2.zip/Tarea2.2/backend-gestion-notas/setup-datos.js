#!/usr/bin/env node
/**
 * Script de Carga Completa de Datos
 * Ejecuta: node setup-datos.js [URL_MONGODB]
 * Ejemplo: node setup-datos.js mongodb://tu-ip:27017/GestionNotas
 */

import mongoose from 'mongoose';
import { Estudiante } from './src/models/estudianteModel.js';
import { Docente } from './src/models/docenteModel.js';
import { Nota } from './src/models/notaModel.js';

// Obtener URL de MongoDB de argumentos o usar default
const mongoURL = process.argv[2] || 'mongodb://localhost:27017/GestionNotas';

console.log('🚀 SETUP COMPLETO DE DATOS - GESTIÓN DE NOTAS');
console.log('═'.repeat(50));
console.log(`📍 Conectando a: ${mongoURL}`);
console.log('═'.repeat(50));

const setupDatos = async () => {
  try {
    // Conectar a MongoDB
    console.log('🌐 Conectando a MongoDB...');
    await mongoose.connect(mongoURL);
    console.log('✅ Conectado exitosamente\n');

    // Limpiar colecciones existentes
    console.log('🧹 Limpiando colecciones previas...');
    await Estudiante.deleteMany({});
    await Docente.deleteMany({});
    await Nota.deleteMany({});
    console.log('✓ Colecciones limpiadas\n');

    // ESTUDIANTES
    console.log('📚 Creando estudiantes...');
    const estudiantes = await Estudiante.insertMany([
      {
        cedula: '1234567001',
        nombre: 'Juan Carlos López',
        email: 'juan.lopez@example.com',
        telefono: '0987654321',
        direccion: 'Calle Principal 123',
        curso: '1ro',
        paralelo: 'A',
        estado: 'activo',
      },
      {
        cedula: '1234567002',
        nombre: 'María García Rodríguez',
        email: 'maria.garcia@example.com',
        telefono: '0987654322',
        direccion: 'Avenida Central 456',
        curso: '2do',
        paralelo: 'B',
        estado: 'activo',
      },
      {
        cedula: '1234567003',
        nombre: 'Pedro Martínez Silva',
        email: 'pedro.martinez@example.com',
        telefono: '0987654323',
        direccion: 'Calle Secundaria 789',
        curso: '3ro',
        paralelo: 'A',
        estado: 'activo',
      },
      {
        cedula: '1234567004',
        nombre: 'Ana Isabel Flores',
        email: 'ana.flores@example.com',
        telefono: '0987654324',
        direccion: 'Boulevard Norte 321',
        curso: '2do',
        paralelo: 'C',
        estado: 'activo',
      },
      {
        cedula: '1234567005',
        nombre: 'Carlos Alberto Ruiz',
        email: 'carlos.ruiz@example.com',
        telefono: '0987654325',
        direccion: 'Calle Este 654',
        curso: '1ro',
        paralelo: 'B',
        estado: 'activo',
      },
    ]);
    console.log(`✓ ${estudiantes.length} estudiantes creados\n`);

    // DOCENTES
    console.log('👨‍🏫 Creando docentes...');
    const docentes = await Docente.insertMany([
      {
        cedula: '9876543001',
        nombre: 'Dr. José González Martínez',
        email: 'jose.gonzalez@example.com',
        telefono: '0987654331',
        area: 'Matemáticas',
        especialidad: 'Cálculo',
        cargaHoraria: 20,
        materias: ['Cálculo I', 'Lógica Matemática'],
        estado: 'activo',
      },
      {
        cedula: '9876543002',
        nombre: 'Ing. Patricia Mendoza López',
        email: 'patricia.mendoza@example.com',
        telefono: '0987654332',
        area: 'Lenguaje y Literatura',
        especialidad: 'Redacción',
        cargaHoraria: 30,
        materias: ['Español I', 'Redacción Académica'],
        estado: 'activo',
      },
      {
        cedula: '9876543003',
        nombre: 'Lic. Roberto Sánchez Díaz',
        email: 'roberto.sanchez@example.com',
        telefono: '0987654333',
        area: 'Ciencias Naturales',
        especialidad: 'Biología',
        cargaHoraria: 40,
        materias: ['Biología Celular'],
        estado: 'activo',
      },
      {
        cedula: '9876543004',
        nombre: 'MSc. Fernando Rodríguez Pérez',
        email: 'fernando.rodriguez@example.com',
        telefono: '0987654334',
        area: 'Estudios Sociales',
        especialidad: 'Historia',
        cargaHoraria: 50,
        materias: ['Historia del Ecuador'],
        estado: 'activo',
      },
      {
        cedula: '9876543005',
        nombre: 'Dra. Elena Torres Guzmán',
        email: 'elena.torres@example.com',
        telefono: '0987654335',
        area: 'Educación Física',
        especialidad: 'Deportes',
        cargaHoraria: 20,
        materias: ['Educación Física'],
        estado: 'activo',
      },
      {
        cedula: '9876543006',
        nombre: 'Lic. Marco Antonio Velasco',
        email: 'marco.velasco@example.com',
        telefono: '0987654336',
        area: 'Matemáticas',
        especialidad: 'Estadística',
        cargaHoraria: 30,
        materias: ['Estadística Descriptiva'],
        estado: 'activo',
      },
      {
        cedula: '9876543007',
        nombre: 'Prof. Alejandra López Ramírez',
        email: 'alejandra.lopez@example.com',
        telefono: '0987654337',
        area: 'Lenguaje y Literatura',
        especialidad: 'Literatura',
        cargaHoraria: 40,
        materias: ['Literatura Universal'],
        estado: 'activo',
      },
      {
        cedula: '9876543008',
        nombre: 'Ing. David Morales Castro',
        email: 'david.morales@example.com',
        telefono: '0987654338',
        area: 'Ciencias Naturales',
        especialidad: 'Química',
        cargaHoraria: 50,
        materias: ['Química I'],
        estado: 'activo',
      },
      {
        cedula: '9876543009',
        nombre: 'MSc. Gloria Estupiñán Ruiz',
        email: 'gloria.estupinan@example.com',
        telefono: '0987654339',
        area: 'Estudios Sociales',
        especialidad: 'Geografía',
        cargaHoraria: 20,
        materias: ['Geografía'],
        estado: 'activo',
      },
      {
        cedula: '9876543010',
        nombre: 'Prof. Luis Alberto Jiménez',
        email: 'luis.jimenez@example.com',
        telefono: '0987654340',
        area: 'Educación Física',
        especialidad: 'Entrenamiento',
        cargaHoraria: 30,
        materias: ['Entrenamiento Deportivo'],
        estado: 'activo',
      },
    ]);
    console.log(`✓ ${docentes.length} docentes creados\n`);

    // NOTAS
    console.log('📊 Creando notas (esto puede tomar un momento)...');
    const asignaturas = [
      'Cálculo I',
      'Programación I',
      'Español I',
      'Física General',
      'Química I',
    ];
    const tiposEval = ['tarea', 'informe', 'leccion', 'participacion', 'proyecto', 'examen'];

    let notasCreadas = 0;
    for (let i = 0; i < estudiantes.length; i++) {
      const estudiante = estudiantes[i];

      for (let tipo of tiposEval) {
        const asignatura = asignaturas[i % asignaturas.length];
        const docente = docentes[(i + tipo.length) % docentes.length];
        const parcial = (tipo === 'tarea' || tipo === 'informe') ? 1 : 
                       (tipo === 'leccion' || tipo === 'participacion') ? 2 : 3;
        const nota = Math.floor(Math.random() * 9) + 12;

        await Nota.create({
          estudiante: estudiante._id,
          estudianteNombre: estudiante.nombre,
          cedula: estudiante.cedula,
          docente: docente._id,
          docenteNombre: docente.nombre,
          asignatura: asignatura,
          curso: estudiante.curso,
          paralelo: estudiante.paralelo,
          parcial: parcial,
          tipoEvaluacion: tipo,
          nota: nota,
          aporte: (nota * 25) / 100,
          porcentaje: 25,
          observaciones: `Evaluación ${tipo} - Parcial ${parcial}`,
          fechaEvaluacion: new Date(2024, parcial + i, Math.floor(Math.random() * 28) + 1),
          estado: 'activo',
        });
        notasCreadas++;
      }
    }
    console.log(`✓ ${notasCreadas} notas creadas\n`);

    // RESUMEN
    console.log('═'.repeat(50));
    console.log('📊 RESUMEN DE DATOS CARGADOS:');
    console.log(`   ✓ ${estudiantes.length} Estudiantes`);
    console.log(`   ✓ ${docentes.length} Docentes`);
    console.log(`   ✓ ${notasCreadas} Registros de Notas`);
    console.log('═'.repeat(50));
    console.log('✅ ¡SETUP COMPLETADO EXITOSAMENTE!');
    console.log('═'.repeat(50));

    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error durante el setup:', error.message);
    console.error(error);
    process.exit(1);
  }
};

setupDatos();
