import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

import { connectDB } from './src/config/mongo.js';
import authRoutes from './src/routes/auth.routes.js';
import estudianteRoutes from './src/routes/estudiante.routes.js';
import docenteRoutes from './src/routes/docente.routes.js';
import notaRoutes from './src/routes/nota.routes.js';

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Conectar a MongoDB
await connectDB();

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/estudiantes', estudianteRoutes);
app.use('/api/docentes', docenteRoutes);
app.use('/api/notas', notaRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ message: 'Servidor de Gestión de Notas corriendo correctamente' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Servidor escuchando en http://localhost:${PORT}`);
  console.log(`📊 Base de datos: ${process.env.MONGODB_URI}`);
});
