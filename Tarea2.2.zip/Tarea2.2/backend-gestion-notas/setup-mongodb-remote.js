#!/usr/bin/env node
/**
 * Script para Configurar MongoDB con Acceso Remoto
 * Ejecuta: node setup-mongodb-remote.js
 */

import { MongoClient } from 'mongodb';
import fs from 'fs';
import os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

console.log('🔧 CONFIGURADOR DE MONGODB REMOTO');
console.log('═'.repeat(50));

const getLocalIP = () => {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
};

const setupRemoteAccess = async () => {
  try {
    const localIP = getLocalIP();
    console.log(`\n🖥️  Tu IP local es: ${localIP}`);
    console.log(`   Comparte esta IP con tu compañero para que se conecte\n`);

    // Verificar que MongoDB esté corriendo
    console.log('📍 Verificando conexión a MongoDB...');
    const client = new MongoClient('mongodb://localhost:27017');
    await client.connect();
    console.log('✅ MongoDB está activo\n');

    // Información de configuración
    console.log('⚙️  PASOS PARA CONFIGURAR ACCESO REMOTO:\n');

    console.log('1️⃣  Encuentra tu archivo mongod.conf:');
    console.log('   • Windows: C:\\Program Files\\MongoDB\\Server\\[versión]\\bin\\mongod.cfg');
    console.log('   • Linux: /etc/mongod.conf');
    console.log('   • macOS: /usr/local/etc/mongod.conf\n');

    console.log('2️⃣  Busca la sección "net:" y cambia:');
    console.log('   Actual:');
    console.log('     bindIp: 127.0.0.1');
    console.log('   Por:');
    console.log('     bindIp: 0.0.0.0\n');

    console.log('3️⃣  Reinicia MongoDB después de los cambios\n');

    console.log('═'.repeat(50));
    console.log('📧 COMPARTE CON TU COMPAÑERO:');
    console.log('═'.repeat(50));
    console.log(`\nCadena de conexión:\n  mongodb://${localIP}:27017/GestionNotas\n`);
    console.log('O usa el script con:');
    console.log(`  node setup-datos.js mongodb://${localIP}:27017/GestionNotas\n`);

    console.log('═'.repeat(50));
    console.log('🔒 SEGURIDAD:');
    console.log('═'.repeat(50));
    console.log('⚠️  Cambiar a 0.0.0.0 expone MongoDB a la red local');
    console.log('   Si quieres más seguridad, usa autenticación:\n');

    console.log('   En MongoDB shell:\n');
    console.log('     use admin');
    console.log('     db.createUser({');
    console.log('       user: "usuario",');
    console.log('       pwd: "contraseña",');
    console.log('       roles: ["readWriteAnyDatabase"]');
    console.log('     })\n');

    console.log('   Luego en mongod.conf agrega:');
    console.log('     security:');
    console.log('       authorization: enabled\n');

    console.log('   Y usa la conexión:');
    console.log(`     mongodb://usuario:contraseña@${localIP}:27017/GestionNotas\n`);

    await client.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error('\n¿MongoDB no está corriendo?');
    console.error('Inicia MongoDB primero y vuelve a ejecutar este script\n');
    process.exit(1);
  }
};

setupRemoteAccess();
