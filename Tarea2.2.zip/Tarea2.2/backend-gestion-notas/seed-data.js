import mongoose from 'mongoose';
import { Estudiante } from './src/models/estudianteModel.js';
import { Docente } from './src/models/docenteModel.js';
import { Nota } from './src/models/notaModel.js';

// Conexión a MongoDB
mongoose.connect('mongodb://localhost:27017/GestionNotas');

const seedData = async () => {
  try {
    console.log('🌱 Iniciando siembra de datos...');

    // Limpiar colecciones existentes
    await Estudiante.deleteMany({});
    await Docente.deleteMany({});
    await Nota.deleteMany({});
    console.log('✓ Colecciones limpiadas');

    // Crear 5 estudiantes con más diversidad
    const estudiantes = await Estudiante.insertMany([
      {
        cedula: '1234567001',
        nombre: 'Juan Carlos López',
        email: 'juan.lopez@mail.com',
        telefono: '0987654321',
        direccion: 'Calle Principal 123',
        curso: '1ro',
        paralelo: 'A',
        estado: 'activo'
      },
      {
        cedula: '1234567002',
        nombre: 'María García Rodríguez',
        email: 'maria.garcia@mail.com',
        telefono: '0987654322',
        direccion: 'Calle Secondary 456',
        curso: '2do',
        paralelo: 'B',
        estado: 'activo'
      },
      {
        cedula: '1234567003',
        nombre: 'Pedro Martínez Silva',
        email: 'pedro.martinez@mail.com',
        telefono: '0987654323',
        direccion: 'Calle Tercera 789',
        curso: '3ro',
        paralelo: 'A',
        estado: 'activo'
      },
      {
        cedula: '1234567004',
        nombre: 'Ana Isabel Flores',
        email: 'ana.flores@mail.com',
        telefono: '0987654324',
        direccion: 'Calle Cuarta 101',
        curso: '2do',
        paralelo: 'C',
        estado: 'activo'
      },
      {
        cedula: '1234567005',
        nombre: 'Carlos Alberto Ruiz',
        email: 'carlos.ruiz@mail.com',
        telefono: '0987654325',
        direccion: 'Calle Quinta 202',
        curso: '1ro',
        paralelo: 'B',
        estado: 'activo'
      }
    ]);
    console.log(`✓ ${estudiantes.length} estudiantes creados`);

    // Crear 10 docentes
    const docentes = await Docente.insertMany([
      {
        cedula: '0987654001',
        nombre: 'Dr. José González Martínez',
        email: 'jose.gonzalez@mail.com',
        telefono: '0912345001',
        area: 'Matemáticas',
        especialidad: 'Cálculo',
        materias: ['Cálculo I', 'Álgebra Lineal'],
        estado: 'activo'
      },
      {
        cedula: '0987654002',
        nombre: 'Ing. Patricia Mendoza López',
        email: 'patricia.mendoza@mail.com',
        telefono: '0912345002',
        area: 'Informática',
        especialidad: 'Programación',
        materias: ['Programación I', 'Estructuras de Datos'],
        estado: 'activo'
      },
      {
        cedula: '0987654003',
        nombre: 'Lic. Roberto Sánchez Díaz',
        email: 'roberto.sanchez@mail.com',
        telefono: '0912345003',
        area: 'Lengua y Literatura',
        especialidad: 'Escritura Académica',
        materias: ['Español I', 'Redacción'],
        estado: 'activo'
      },
      {
        cedula: '0987654004',
        nombre: 'MSc. Fernando Rodríguez Pérez',
        email: 'fernando.rodriguez@mail.com',
        telefono: '0912345004',
        area: 'Física',
        especialidad: 'Mecánica',
        materias: ['Física General', 'Cinemática'],
        estado: 'activo'
      },
      {
        cedula: '0987654005',
        nombre: 'Dra. Elena Torres Guzmán',
        email: 'elena.torres@mail.com',
        telefono: '0912345005',
        area: 'Química',
        especialidad: 'Química Orgánica',
        materias: ['Química I', 'Laboratorio'],
        estado: 'activo'
      },
      {
        cedula: '0987654006',
        nombre: 'Lic. Marco Antonio Velasco',
        email: 'marco.velasco@mail.com',
        telefono: '0912345006',
        area: 'Historia',
        especialidad: 'Historia Contemporánea',
        materias: ['Historia General', 'Historia de América'],
        estado: 'activo'
      },
      {
        cedula: '0987654007',
        nombre: 'Prof. Alejandra López Ramírez',
        email: 'alejandra.lopez@mail.com',
        telefono: '0912345007',
        area: 'Idiomas',
        especialidad: 'Inglés',
        materias: ['Inglés I', 'Conversación'],
        estado: 'activo'
      },
      {
        cedula: '0987654008',
        nombre: 'Ing. David Morales Castro',
        email: 'david.morales@mail.com',
        telefono: '0912345008',
        area: 'Electrónica',
        especialidad: 'Circuitos',
        materias: ['Electrónica Digital', 'Circuitos Eléctricos'],
        estado: 'activo'
      },
      {
        cedula: '0987654009',
        nombre: 'MSc. Gloria Estupiñán Ruiz',
        email: 'gloria.estupinan@mail.com',
        telefono: '0912345009',
        area: 'Educación Física',
        especialidad: 'Deportes',
        materias: ['Educación Física', 'Deportes Competitivos'],
        estado: 'activo'
      },
      {
        cedula: '0987654010',
        nombre: 'Prof. Luis Alberto Jiménez',
        email: 'luis.jimenez@mail.com',
        telefono: '0912345010',
        area: 'Artes',
        especialidad: 'Artes Plásticas',
        materias: ['Dibujo', 'Pintura'],
        estado: 'activo'
      }
    ]);
    console.log(`✓ ${docentes.length} docentes creados`);

    // Crear notas para cada estudiante - Más diversidad
    const asignaturas = ['Cálculo I', 'Programación I', 'Español I', 'Física General', 'Química I'];
    const tiposEval = ['tarea', 'informe', 'leccion', 'participacion', 'proyecto', 'examen'];
    const porcentajes = { tarea: 20, informe: 20, leccion: 20, participacion: 15, proyecto: 25, examen: 40 };

    let notasCreadas = 0;

    for (let i = 0; i < estudiantes.length; i++) {
      const estudiante = estudiantes[i];
      
      // Crear múltiples evaluaciones de diferentes tipos
      for (let tipo of tiposEval) {
        const asignatura = asignaturas[i % asignaturas.length];
        const docente = docentes[(i + tipo.length) % docentes.length];
        const parcial = (tipo === 'tarea' || tipo === 'informe') ? 1 : (tipo === 'leccion' || tipo === 'participacion') ? 2 : 3;
        
        // Generar nota aleatoria entre 12 y 20 (notas realistas)
        const nota = Math.floor(Math.random() * 9) + 12; // 12-20

        // Crear registro de nota individual
        const nuevaNota = await Nota.create({
          estudiante: estudiante._id,
          estudianteNombre: estudiante.nombre,
          cedula: estudiante.cedula,
          docente: docente._id,
          docenteNombre: docente.nombre,
          asignatura: asignatura,
          curso: estudiante.curso,
          paralelo: estudiante.paralelo,
          parcial: parcial,
          tipoEvaluacion: tipo,
          nota: nota,
          aporte: (nota * (porcentajes[tipo] || 25)) / 100,
          porcentaje: porcentajes[tipo] || 25,
          observaciones: `Evaluación ${tipo} - Parcial ${parcial} - ${asignatura}`,
          fechaEvaluacion: new Date(2024, parcial + i, Math.floor(Math.random() * 28) + 1),
          estado: 'activo'
        });

        notasCreadas++;
      }
    }

    console.log(`✓ ${notasCreadas} notas creadas (diversidad de evaluaciones)`);

    // Resumen de datos
    console.log('\n📊 RESUMEN DE DATOS CREADOS:');
    console.log(`   ✓ ${estudiantes.length} Estudiantes (1ro, 2do, 3ro con paralelos A, B, C)`);
    console.log(`   ✓ ${docentes.length} Docentes (10 áreas diferentes)`);
    console.log(`   ✓ ${notasCreadas} Registros de Notas (6 tipos de evaluación x 5 estudiantes)`);
    console.log('\n✅ Siembra de datos completada exitosamente!');

    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error al sembrar datos:', error);
    process.exit(1);
  }
};

seedData();
