import mongoose from 'mongoose';
import { Docente } from './src/models/docenteModel.js';

const areas = [
  'Matemáticas',
  'Lenguaje y Literatura',
  'Ciencias Naturales',
  'Estudios Sociales',
  'Educación Física',
];

const especialidades = {
  'Matemáticas': ['Álgebra', 'Geometría', 'Cálculo', 'Estadística'],
  'Lenguaje y Literatura': ['Gramática', 'Literatura', 'Redacción'],
  'Ciencias Naturales': ['Biología', 'Química', 'Física'],
  'Estudios Sociales': ['Historia', 'Geografía', 'Educación Cívica'],
  'Educación Física': ['Deportes', 'Entrenamiento', 'Nutrición'],
};

const materias = [
  'Cálculo I',
  'Programación I',
  'Español I',
  'Física General',
  'Química I',
  'Historia del Ecuador',
  'Educación Física',
  'Inglés Básico',
  'Lógica Matemática',
  'Introdución a la Informática',
];

const cargasHorarias = [20, 30, 40, 50];

const updateDocentes = async () => {
  try {
    console.log('🌐 Conectando a MongoDB...');
    await mongoose.connect('mongodb://localhost:27017/GestionNotas');

    console.log('📝 Actualizando docentes...');
    const docentes = await Docente.find();

    for (let i = 0; i < docentes.length; i++) {
      const docente = docentes[i];
      const area = areas[i % areas.length];
      const especialidadesArea = especialidades[area];
      const especialidad = especialidadesArea[i % especialidadesArea.length];
      const cargaHoraria = cargasHorarias[i % cargasHorarias.length];
      
      // Seleccionar 2-3 materias aleatorias
      const materiasAsignadas = [];
      for (let j = 0; j < Math.floor(Math.random() * 2) + 2; j++) {
        const materia = materias[Math.floor(Math.random() * materias.length)];
        if (!materiasAsignadas.includes(materia)) {
          materiasAsignadas.push(materia);
        }
      }

      await Docente.findByIdAndUpdate(docente._id, {
        area,
        especialidad,
        cargaHoraria,
        materias: materiasAsignadas,
      });

      console.log(`✓ ${docente.nombre} - Area: ${area}, Carga: ${cargaHoraria}h`);
    }

    console.log('\n✅ Todos los docentes actualizados correctamente!');
    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error al actualizar docentes:', error);
    process.exit(1);
  }
};

updateDocentes();
