# 🎓 GESTIÓN DE NOTAS - SETUP COMPLETO

## Para tu compañero - Lee primero ⭐

Si tu compañero va a usar tu MongoDB remoto, comparte:
- **Tu IP**: `192.168.18.10`
- **Puerto MongoDB**: `27017`
- **Base de datos**: `GestionNotas`
- **Script a ejecutar**: `node setup-datos.js mongodb://192.168.18.10:27017/GestionNotas`

---

## 📥 INSTALACIÓN RÁPIDA (< 5 minutos)

### Paso 1: Clonar/Descargar el proyecto
```bash
git clone [tu-repo]
cd Tarea2.2
```

### Paso 2: Instalar dependencias backend
```bash
cd backend-gestion-notas
npm install
```

### Paso 3: Cargar datos (elige una opción)

**Opción A - MongoDB Local:**
```bash
node setup-datos.js
```

**Opción B - MongoDB Remoto (compañero):**
```bash
node setup-datos.js mongodb://192.168.18.10:27017/GestionNotas
```

### Paso 4: Iniciar el backend
```bash
npm start
```
El backend corre en `http://localhost:3001`

### Paso 5: En otra terminal, iniciar el frontend
```bash
cd ../frontend-gestion-notas
npm install
npm start
```
El frontend abre automáticamente en `http://localhost:3000`

---

## 🎯 Lo que carga el script

| Componente | Cantidad | Detalles |
|-----------|----------|---------|
| **Estudiantes** | 5 | Cédula, email, teléfono, dirección, curso (1ro/2do/3ro), paralelo |
| **Docentes** | 10 | Área, especialidad, carga horaria (20-50h), materias asignadas |
| **Notas** | 30 | 6 tipos de evaluación, parciales, calificaciones 12-20 |

---

## 🌐 Acceso Remoto a MongoDB

### Si TÚ quieres compartir tu MongoDB:

1. Ejecuta el script helper (opcional):
   ```bash
   node setup-mongodb-remote.js
   ```

2. Edita `mongod.conf`:
   ```ini
   net:
     bindIp: 0.0.0.0  # Cambiar de 127.0.0.1
   ```

3. Reinicia MongoDB y comparte tu IP

4. **IMPORTANTE**: Considera habilitar autenticación para seguridad

### Si tu COMPAÑERO quiere conectarse a tu MongoDB:

Pídele que ejecute:
```bash
node setup-datos.js mongodb://TU_IP:27017/GestionNotas
```

Ejemplo:
```bash
node setup-datos.js mongodb://192.168.18.10:27017/GestionNotas
```

---

## 📋 Estructura del Proyecto

```
Tarea2.2/
├── backend-gestion-notas/
│   ├── app.js                 # Aplicación principal
│   ├── package.json           # Dependencias
│   ├── setup-datos.js         # ⭐ SCRIPT PRINCIPAL
│   ├── setup-mongodb-remote.js
│   ├── seed-data.js           # (Alternativa antigua)
│   ├── update-docentes.js     # (Alternativa antigua)
│   └── src/
│       ├── models/            # Esquemas Mongoose
│       ├── routes/            # Endpoints API
│       └── controllers/       # Lógica de negocio
│
├── frontend-gestion-notas/
│   ├── package.json
│   ├── src/
│   │   ├── pages/            # Estudiantes, Docentes, Notas, Dashboard
│   │   ├── components/       # Formularios, Listas
│   │   └── App.js
│   └── public/
│
└── SETUP_GUIDE.md            # Esta guía

```

---

## 🚀 URLs Útiles

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3001
- **API Endpoints**:
  - `GET /api/estudiantes` - Lista estudiantes
  - `GET /api/docentes` - Lista docentes
  - `GET /api/notas` - Lista notas
  - `POST /api/estudiantes` - Crear estudiante
  - `POST /api/docentes` - Crear docente
  - `POST /api/notas` - Crear nota

---

## ⚡ Troubleshooting

### ❌ "Error: Cannot find module 'mongoose'"
```bash
npm install
```

### ❌ "Error: connect ECONNREFUSED"
- MongoDB no está corriendo
- Verifica la URL (localhost vs IP remota)
- Usa: `node setup-dados.js mongodb://IP_CORRECTA:27017/GestionNotas`

### ❌ "Error: 127.0.0.1:27017 no alcanzable"
- MongoDB no escucha en 0.0.0.0
- Edita `mongod.conf` y cambia `bindIp`
- Reinicia MongoDB

### ❌ "Error: getaddrinfo ENOTFOUND"
- La IP no existe o no es alcanzable
- Verifica: `ping 192.168.18.10`
- Comprueba que ambas PCs estén en la misma red

---

## 📊 Dashboard

Después de ejecutar el setup, verás en el dashboard:

```
📚 Estudiantes: 5
👨‍🏫 Docentes: 10
📝 Notas: 30
```

Cada vez que creas nuevos registros, se actualizan en tiempo real.

---

## 🔐 Consideraciones de Seguridad

⚠️ **Bindear a 0.0.0.0 = Acceso desde la red local**

Para mayor seguridad:
1. Usa autenticación en MongoDB
2. Restringe a una red específica
3. Usa VPN o conexión SSH tunneling
4. Cambia los puertos por defecto

---

## 💡 Notas Importantes

✅ El script `setup-datos.js` es **idempotente**
   - Puedes ejecutarlo múltiples veces
   - Limpia y recarga los datos cada vez

✅ Los datos de ejemplo son **ficticios** y están listos para editar

✅ La aplicación es **full-stack**:
   - React en frontend
   - Express en backend
   - MongoDB para persistencia

✅ Todos los CRUD funcionan (Create, Read, Update, Delete)

---

## 🆘 ¿Necesitas Ayuda?

1. Revisa el console del navegador (F12)
2. Revisa los logs del backend en la terminal
3. Verifica la conexión a MongoDB
4. Ejecuta de nuevo: `node setup-datos.js`

---

## 📞 Resumen de Comandos

```bash
# Setup
npm install
node setup-datos.js

# Iniciar (dos terminales)
npm start                    # Terminal 1: Backend
npm start                    # Terminal 2: Frontend (después de cd frontend-gestion-notas)

# Opciones
node setup-datos.js mongodb://192.168.18.10:27017/GestionNotas
node setup-mongodb-remote.js
```

---

**¡Listo! Ahora a disfrutar del sistema de gestión de notas 🎓**
