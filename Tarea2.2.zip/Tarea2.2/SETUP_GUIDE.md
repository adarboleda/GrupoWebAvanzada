# 📚 GUÍA DE SETUP - GESTIÓN DE NOTAS

## Quick Start - Tres pasos sencillos:

### 1️⃣ Preparar el Backend
```bash
cd backend-gestion-notas
npm install
```

### 2️⃣ Ejecutar el Script de Datos

**Opción A - Conexión Local (si MongoDB está en su máquina):**
```bash
node setup-datos.js
```

**Opción B - Conexión Remota (conectarse al MongoDB de otra PC):**
```bash
node setup-datos.js mongodb://IP_DEL_COMPAÑERO:27017/GestionNotas
```

Ejemplo:
```bash
node setup-datos.js mongodb://192.168.18.10:27017/GestionNotas
```

### 3️⃣ Iniciar el Sistema
```bash
# Terminal 1 - Backend
npm start

# Terminal 2 - Frontend
cd ../frontend-gestion-notas
npm install
npm start
```

---

## 📋 Qué Carga el Script

✅ **5 Estudiantes**
- Todos con datos completos (cédula, email, teléfono, dirección)
- Distribuidos en 1ro, 2do y 3ro de bachillerato
- Diferentes paralelos (A, B, C)

✅ **10 Docentes**
- Con área especializada (Matemáticas, Lenguaje, Ciencias, etc.)
- Carga horaria (20h, 30h, 40h, 50h)
- Materias asignadas

✅ **30 Registros de Notas**
- 6 tipos de evaluación: tarea, informe, lección, participación, proyecto, examen
- Distribuidas entre todos los estudiantes
- Calificaciones entre 12 y 20
- Asociadas a docentes y parciales

---

## 🔧 Requisitos

- **Node.js** v16 o superior
- **MongoDB** en su máquina o acceso remoto
- **npm** (viene con Node.js)

---

## ⚠️ Importante

El script **limpia las colecciones previas** antes de insertar datos. Si tienes datos importantes, **haz un backup primero**.

---

## 🆘 Solución de Problemas

**Error: "Cannot find module"**
```bash
npm install
```

**Error: "connect ECONNREFUSED"**
- Verificar que MongoDB esté corriendo
- Verificar la URL de conexión (IP correcta, puerto 27017)

**Error: "getaddrinfo ENOTFOUND"**
- La IP no es alcanzable
- Verificar con: `ping 192.168.18.10`
- Asegurarse que MongoDB escuche en todas las interfaces (0.0.0.0)

---

## 💡 Notas

- El script es **idempotente**: puedes ejecutarlo múltiples veces
- Los datos se cargan en la base de datos `GestionNotas`
- Después de ejecutar, los datos están listos en el Dashboard
