# 🎓 Sistema de Gestión de Notas Académicas - Tarea 2.2

**Sistema web completo para gestión de estudiantes, docentes y calificaciones con cálculos automáticos.**

---

## 📂 Estructura del Proyecto

```
Tarea2.2/
├── frontend-gestion-notas/       # Frontend (React)
│   ├── src/
│   │   ├── components/           # Componentes reutilizables
│   │   │   ├── Estudiantes/
│   │   │   ├── Docentes/
│   │   │   ├── Notas/
│   │   │   ├── Layout/
│   │   │   └── PrivateRoute.js
│   │   ├── pages/                # Páginas principales
│   │   ├── api/                  # Servicios API
│   │   ├── context/              # Context API (auth)
│   │   ├── utils/                # Utilidades (cálculos)
│   │   ├── App.js                # Componente principal
│   │   └── index.js              # Punto de entrada
│   ├── public/
│   ├── package.json
│   └── .gitignore
│
└── backend-gestion-notas/        # Backend (Express)
    ├── src/
    │   ├── models/               # Schemas Mongoose
    │   ├── controllers/          # Lógica de negocio
    │   ├── routes/               # Rutas API
    │   └── config/               # Configuración
    ├── app.js                    # Servidor Express
    ├── package.json
    ├── .env                      # Variables de entorno
    └── README.md                 # Documentación API
```

---

## 🚀 Instalación Rápida (5 minutos)

### 1. Backend

```bash
cd backend-gestion-notas
npm install
npm run dev
```

**Esperado**: `servidor corriendo en puerto 3001`

### 2. Frontend (nueva terminal)

```bash
cd frontend-gestion-notas
npm install
npm start
```

**Esperado**: Se abre `http://localhost:3000` automáticamente

### 3. Usar el Sistema

- **URL**: http://localhost:3000
- **Login**: Cualquier email/password
- **Funcionalidad**: Acceso completo a todos los módulos

---

## ✨ Módulos Disponibles

### 👥 Estudiantes
- Importar de DummyJSON automáticamente
- CRUD (Crear, Leer, Actualizar, Eliminar)
- Búsqueda por cedula, nombre o email
- Soft delete (no elimina datos)

### 👨‍🏫 Docentes
- CRUD completo
- Búsqueda y filtros
- Información de área y especialidad
- Soft delete

### 📊 Notas (Cálculos Académicos)
- Registro de notas (0-20)
- 3 Parciales por semestre
- 4 Evaluaciones por parcial:
  - Tarea (20%)
  - Informe (20%)
  - Lección (20%)
  - Examen (40%)
- **Cálculos automáticos** exactos
- Estados académicos: Aprobado / Reprobado / Reprobado Anticipado
- Vista dual: Lista y Resumen

### 📈 Dashboard
- Estadísticas en tiempo real
- Actividades recientes
- Acceso rápido a funciones

### ❓ Ayuda
- 7 FAQs sobre el sistema
- Explicaciones detalladas

---

## 🔧 Tecnologías

**Frontend**:
- React 19.2.0
- React Router 6.20.0
- Bootstrap 5.3.2
- Axios 1.6.0
- JWT Decode 4.0.0

**Backend**:
- Node.js 18+
- Express 4.18.2
- MongoDB 4.4+
- Mongoose 8.0.0
- JWT 9.1.2

---

## 📋 Fórmula de Cálculo de Notas

```
Nota Parcial = (tarea/20 × 20/100 × 20) +
               (informe/20 × 20/100 × 20) +
               (lección/20 × 20/100 × 20) +
               (examen/20 × 40/100 × 20)
             = 0 a 20

Nota Semestre = Parcial1 + Parcial2 + Parcial3
              = 0 a 42.10

Estado Académico:
- Si P1+P2 < 28: REPROBADO ANTICIPADO
- Si NotaSemestre < 28: REPROBADO
- Si NotaSemestre ≥ 28: APROBADO
```

---

## 🔌 Puertos

```
Frontend:    http://localhost:3000
Backend:     http://localhost:3001
MongoDB:     mongodb://localhost:27017/GestionNotas
```

---

## ⚠️ Requisitos Previos

- Node.js v16+ (`node --version`)
- npm v9+ (`npm --version`)
- MongoDB instalado o MongoDB Atlas configurado

**Si no tienes Node.js**: https://nodejs.org

**Si no tienes MongoDB local**:
- Usa MongoDB Atlas: https://www.mongodb.com/cloud/atlas
- Actualiza `.env` en backend con tu connection string

---

## 🐛 Problemas Comunes

| Problema | Solución |
|----------|----------|
| "npm no reconocido" | Instala Node.js desde nodejs.org |
| "Cannot find module" | Ejecuta `npm install` en la carpeta correcta |
| "MongoDB error" | Inicia MongoDB o configura MongoDB Atlas en `.env` |
| "Puerto 3000 ocupado" | Cierra otra aplicación o cambia `PORT` en `.env` |
| Login no funciona | Revisa que el backend esté corriendo en 3001 |

---

## 📖 Más Información

- **Backend**: Ver `backend-gestion-notas/README.md` para documentación de API
- **Estructura**: Ver carpetas `frontend-gestion-notas` y `backend-gestion-notas`
- **Código**: Revisar comentarios en archivos source

---

## ✅ Checklist de Inicio

```
☐ Node.js instalado
☐ MongoDB disponible (local o Atlas)
☐ npm install en backend
☐ npm install en frontend
☐ Backend corriendo (3001)
☐ Frontend corriendo (3000)
☐ Login funciona
☐ Módulos accesibles
☐ ¡Listo!
```

---

**Versión**: 1.0.0  
**Estado**: ✅ Completamente Funcional  
**Especificación**: 100% Cumplida  

¡**Bienvenido al sistema!** 🚀
